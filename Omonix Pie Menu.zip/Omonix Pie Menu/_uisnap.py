# File: _uisnap.py (FINAL FIX: Snap Jump to Pointer and Translated)
import bpy
from mathutils import Vector 
from bpy_extras.view3d_utils import region_2d_to_vector_3d, region_2d_to_location_3d

class OMONIX_OT_CallPlaceTool(bpy.types.Operator):
    """
    Calls 'ph.move_object' Place Helper for Snap/Move. 
    Object jumps to the mouse pointer position, then moves following the mouse.
    """
    bl_idname = "omonix.call_place_tool"
    bl_label = "Snap/Move to Pointer"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Jump active object to mouse pointer location and start interactive move/snap session (Place Helper required)."

    def invoke(self, context, event):
        if not context.active_object:
            self.report({'WARNING'}, "No active object selected to move.")
            return {'CANCELLED'}
        
        active_obj = context.active_object
        
        # --- 1. RAY CAST LOGIC (FINDING 3D POSITION UNDER MOUSE) ---
        target_loc = context.scene.cursor.location.copy() 
        
        region = context.region
        rv3d = context.region_data
        
        if region and rv3d:
            mouse_pos = (event.mouse_region_x, event.mouse_region_y)
            vec = region_2d_to_vector_3d(region, rv3d, mouse_pos)
            ray_origin = region_2d_to_location_3d(region, rv3d, mouse_pos, vec)
            
            result, location, normal, index, obj, matrix = context.scene.ray_cast(context.view_layer.depsgraph, ray_origin, vec)
            if result:
                target_loc = location
                
        # --- 2. CALCULATE MOVEMENT VECTOR (DELTA) ---
        # This is how far the object needs to move from its current position (current_loc) 
        # to reach the Ray-Cast position (target_loc).
        current_loc = active_obj.matrix_world.translation
        delta_vector = target_loc - current_loc
        
        # --- 3. START INTERACTIVE MOVE SESSION (INVOKE_DEFAULT) ---
        
        move_args = {'value': delta_vector, 'orient_type': 'GLOBAL'}
        
        # Try calling Place Helper, if successful, it will start from the new position.
        try:
            # IMPORTANT: Use EXEC_DEFAULT for instant jump, then INVOKE_DEFAULT
            # for the interactive session.
            bpy.ops.transform.translate('EXEC_DEFAULT', **move_args) # Instant Jump
            
            bpy.ops.ph.move_object('INVOKE_DEFAULT') # Interactive Session from the new location
            self.report({'INFO'}, "Place Helper called.")
            
        except (AttributeError, RuntimeError):
            # Fallback: Directly call the standard Move tool with the initial jump (delta_vector)
            self.report({'INFO'}, "Place Helper not found. Running default Move tool interactively.")
            bpy.ops.transform.translate('INVOKE_DEFAULT', **move_args)
            
        return {'FINISHED'}
    
    def execute(self, context): 
        return {'FINISHED'} 

# --- Class Registration ---
classes_to_register = (
    OMONIX_OT_CallPlaceTool,
)