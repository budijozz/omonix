import bpy, mathutils

#initialize smoothgraw_gn node group
def smoothgraw_gn_node_group():
    smoothgraw_gn = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "smoothgraw_gn")

    # [API FIX]: Baris color_tag dan default_group_node_width dihapus
    smoothgraw_gn.description = ""
    
    #smoothgraw_gn interface
    #Socket Geometry
    geometry_socket = smoothgraw_gn.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Curve
    curve_socket = smoothgraw_gn.interface.new_socket(name = "Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    curve_socket.attribute_domain = 'POINT'

    #Socket Radius
    radius_socket = smoothgraw_gn.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
    radius_socket.default_value = 20.0
    radius_socket.min_value = 0.0
    radius_socket.max_value = 3.4028234663852886e+38
    radius_socket.subtype = 'DISTANCE'
    radius_socket.attribute_domain = 'POINT'

    #Socket Density
    density_socket = smoothgraw_gn.interface.new_socket(name = "Density", in_out='INPUT', socket_type = 'NodeSocketFloat')
    density_socket.default_value = 2.2999963760375977
    density_socket.min_value = 0.009999999776482582
    density_socket.max_value = 3.4028234663852886e+38
    density_socket.subtype = 'NONE'
    density_socket.attribute_domain = 'POINT'

    #Socket Iterations
    iterations_socket = smoothgraw_gn.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
    iterations_socket.default_value = 5
    iterations_socket.min_value = 0
    iterations_socket.max_value = 2147483647
    iterations_socket.subtype = 'NONE'
    iterations_socket.attribute_domain = 'POINT'

    #Socket Weight
    weight_socket = smoothgraw_gn.interface.new_socket(name = "Weight", in_out='INPUT', socket_type = 'NodeSocketFloat')
    weight_socket.default_value = 0.75
    weight_socket.min_value = 0.0
    weight_socket.max_value = 1.0
    weight_socket.subtype = 'FACTOR'
    weight_socket.attribute_domain = 'POINT'

    #Panel ☛ Want Detail Voxel  ☚
    __want_detail_voxel____panel = smoothgraw_gn.interface.new_panel("☛ Want Detail Voxel  ☚")
    #Socket JML VOXEL AVM
    jml_voxel_avm_socket = smoothgraw_gn.interface.new_socket(name = "JML VOXEL AVM", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __want_detail_voxel____panel)
    jml_voxel_avm_socket.default_value = 50.0
    jml_voxel_avm_socket.min_value = 0.0
    jml_voxel_avm_socket.max_value = 3.4028234663852886e+38
    jml_voxel_avm_socket.subtype = 'NONE'
    jml_voxel_avm_socket.attribute_domain = 'POINT'

    #Socket jml Voxel BVM
    jml_voxel_bvm_socket = smoothgraw_gn.interface.new_socket(name = "jml Voxel BVM", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __want_detail_voxel____panel)
    jml_voxel_bvm_socket.default_value = 50.0
    jml_voxel_bvm_socket.min_value = 0.0
    jml_voxel_bvm_socket.max_value = 3.4028234663852886e+38
    jml_voxel_bvm_socket.subtype = 'NONE'
    jml_voxel_bvm_socket.attribute_domain = 'POINT'



    #initialize smoothgraw_gn nodes
    #node Group Output
    group_output = smoothgraw_gn.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Realize Instances
    realize_instances = smoothgraw_gn.nodes.new("GeometryNodeRealizeInstances")
    realize_instances.name = "Realize Instances"
    #Selection
    realize_instances.inputs[1].default_value = True
    #Realize All
    realize_instances.inputs[2].default_value = True
    #Depth
    realize_instances.inputs[3].default_value = 0

    #node Set Shade Smooth
    set_shade_smooth = smoothgraw_gn.nodes.new("GeometryNodeSetShadeSmooth")
    set_shade_smooth.name = "Set Shade Smooth"
    set_shade_smooth.domain = 'FACE'
    #Selection
    set_shade_smooth.inputs[1].default_value = True
    #Shade Smooth
    set_shade_smooth.inputs[2].default_value = True

    #node Curve to Mesh
    curve_to_mesh = smoothgraw_gn.nodes.new("GeometryNodeCurveToMesh")
    curve_to_mesh.name = "Curve to Mesh"
    #Fill Caps
    curve_to_mesh.inputs[2].default_value = True

    #node Mesh to Volume
    mesh_to_volume = smoothgraw_gn.nodes.new("GeometryNodeMeshToVolume")
    mesh_to_volume.name = "Mesh to Volume"
    mesh_to_volume.resolution_mode = 'VOXEL_AMOUNT'
    #Interior Band Width
    mesh_to_volume.inputs[4].default_value = 1.0

    #node Trim Curve
    trim_curve = smoothgraw_gn.nodes.new("GeometryNodeTrimCurve")
    trim_curve.name = "Trim Curve"
    trim_curve.mode = 'FACTOR'
    #Selection
    trim_curve.inputs[1].default_value = True
    #Start
    trim_curve.inputs[2].default_value = 0.0
    #End
    trim_curve.inputs[3].default_value = 1.0

    #node Volume to Mesh
    volume_to_mesh = smoothgraw_gn.nodes.new("GeometryNodeVolumeToMesh")
    volume_to_mesh.name = "Volume to Mesh"
    volume_to_mesh.resolution_mode = 'VOXEL_AMOUNT'
    #Threshold
    volume_to_mesh.inputs[3].default_value = 0.25
    #Adaptivity
    volume_to_mesh.inputs[4].default_value = 0.0

    #node Curve Circle
    curve_circle = smoothgraw_gn.nodes.new("GeometryNodeCurvePrimitiveCircle")
    curve_circle.name = "Curve Circle"
    curve_circle.mode = 'RADIUS'
    #Resolution
    curve_circle.inputs[0].default_value = 50

    #node Blur Attribute
    blur_attribute = smoothgraw_gn.nodes.new("GeometryNodeBlurAttribute")
    blur_attribute.name = "Blur Attribute"
    blur_attribute.data_type = 'FLOAT_VECTOR'

    #node Group Input
    group_input = smoothgraw_gn.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Set Position
    set_position = smoothgraw_gn.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"
    #Selection
    set_position.inputs[1].default_value = True
    #Offset
    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)

    #node Position
    position = smoothgraw_gn.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"





    #Set locations
    group_output.location = (1089.9268798828125, -36.449546813964844)
    realize_instances.location = (248.925048828125, 48.92664337158203)
    set_shade_smooth.location = (773.2301635742188, 71.06795501708984)
    curve_to_mesh.location = (-369.1913146972656, 48.039817810058594)
    mesh_to_volume.location = (-197.725341796875, 51.66999053955078)
    trim_curve.location = (-613.9948120117188, 152.1015167236328)
    volume_to_mesh.location = (39.99596405029297, 52.008811950683594)
    curve_circle.location = (-611.8809204101562, -24.48720932006836)
    blur_attribute.location = (288.41021728515625, -107.44374084472656)
    group_input.location = (-934.8941650390625, -152.30340576171875)
    set_position.location = (548.7305908203125, -86.2169189453125)
    position.location = (14.493141174316406, -238.6593475341797)

    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    realize_instances.width, realize_instances.height = 140.0, 100.0
    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
    mesh_to_volume.width, mesh_to_volume.height = 200.0, 100.0
    trim_curve.width, trim_curve.height = 140.0, 100.0
    volume_to_mesh.width, volume_to_mesh.height = 170.0, 100.0
    curve_circle.width, curve_circle.height = 140.0, 100.0
    blur_attribute.width, blur_attribute.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    set_position.width, set_position.height = 140.0, 100.0
    position.width, position.height = 140.0, 100.0

    #initialize smoothgraw_gn links
    #volume_to_mesh.Mesh -> realize_instances.Geometry
    smoothgraw_gn.links.new(volume_to_mesh.outputs[0], realize_instances.inputs[0])
    #curve_circle.Curve -> curve_to_mesh.Profile Curve
    smoothgraw_gn.links.new(curve_circle.outputs[0], curve_to_mesh.inputs[1])
    #mesh_to_volume.Volume -> volume_to_mesh.Volume
    smoothgraw_gn.links.new(mesh_to_volume.outputs[0], volume_to_mesh.inputs[0])
    #set_position.Geometry -> set_shade_smooth.Geometry
    smoothgraw_gn.links.new(set_position.outputs[0], set_shade_smooth.inputs[0])
    #curve_to_mesh.Mesh -> mesh_to_volume.Mesh
    smoothgraw_gn.links.new(curve_to_mesh.outputs[0], mesh_to_volume.inputs[0])
    #blur_attribute.Value -> set_position.Position
    smoothgraw_gn.links.new(blur_attribute.outputs[0], set_position.inputs[2])
    #position.Position -> blur_attribute.Value
    smoothgraw_gn.links.new(position.outputs[0], blur_attribute.inputs[0])
    #realize_instances.Geometry -> set_position.Geometry
    smoothgraw_gn.links.new(realize_instances.outputs[0], set_position.inputs[0])
    #trim_curve.Curve -> curve_to_mesh.Curve
    smoothgraw_gn.links.new(trim_curve.outputs[0], curve_to_mesh.inputs[0])
    #set_shade_smooth.Geometry -> group_output.Geometry
    smoothgraw_gn.links.new(set_shade_smooth.outputs[0], group_output.inputs[0])
    #group_input.Radius -> curve_circle.Radius
    smoothgraw_gn.links.new(group_input.outputs[1], curve_circle.inputs[4])
    #group_input.Curve -> trim_curve.Curve
    smoothgraw_gn.links.new(group_input.outputs[0], trim_curve.inputs[0])
    #group_input.Density -> mesh_to_volume.Density
    smoothgraw_gn.links.new(group_input.outputs[2], mesh_to_volume.inputs[1])
    #group_input.Iterations -> blur_attribute.Iterations
    smoothgraw_gn.links.new(group_input.outputs[3], blur_attribute.inputs[1])
    #group_input.jml Voxel BVM -> volume_to_mesh.Voxel Amount
    smoothgraw_gn.links.new(group_input.outputs[6], volume_to_mesh.inputs[2])
    #group_input.Weight -> blur_attribute.Weight
    smoothgraw_gn.links.new(group_input.outputs[4], blur_attribute.inputs[2])
    #group_input.JML VOXEL AVM -> mesh_to_volume.Voxel Amount
    smoothgraw_gn.links.new(group_input.outputs[5], mesh_to_volume.inputs[3])
    return smoothgraw_gn

smoothgraw_gn = smoothgraw_gn_node_group()

#initialize smooth_draw node group
def smooth_draw_node_group():
    smooth_draw = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "smooth_draw")

    # [API FIX]: Baris color_tag dan default_group_node_width dihapus
    smooth_draw.description = ""
    
    smooth_draw.is_modifier = True

    #smooth_draw interface
    #Socket Geometry
    geometry_socket_1 = smooth_draw.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_2 = smooth_draw.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_2.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_3 = smooth_draw.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_3.attribute_domain = 'POINT'

    #Socket Radius
    radius_socket_1 = smooth_draw.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
    radius_socket_1.default_value = 0.29999980330467224
    radius_socket_1.min_value = 0.0
    radius_socket_1.max_value = 3.4028234663852886e+38
    radius_socket_1.subtype = 'DISTANCE'
    radius_socket_1.attribute_domain = 'POINT'

    #Socket Density
    density_socket_1 = smooth_draw.interface.new_socket(name = "Density", in_out='INPUT', socket_type = 'NodeSocketFloat')
    density_socket_1.default_value = 6.799996376037598
    density_socket_1.min_value = 0.009999999776482582
    density_socket_1.max_value = 3.4028234663852886e+38
    density_socket_1.subtype = 'NONE'
    density_socket_1.attribute_domain = 'POINT'

    #Socket Iterations
    iterations_socket_1 = smooth_draw.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
    iterations_socket_1.default_value = 8
    iterations_socket_1.min_value = 0
    iterations_socket_1.max_value = 2147483647
    iterations_socket_1.subtype = 'NONE'
    iterations_socket_1.attribute_domain = 'POINT'


    #initialize smooth_draw nodes
    #node Group Output
    group_output_1 = smooth_draw.nodes.new("NodeGroupOutput")
    group_output_1.name = "Group Output"
    group_output_1.is_active_output = True

    #node Group Input
    group_input_1 = smooth_draw.nodes.new("NodeGroupInput")
    group_input_1.name = "Group Input"

    #node Group
    group = smooth_draw.nodes.new("GeometryNodeGroup")
    group.name = "Group"
    group.node_tree = smoothgraw_gn
    #Socket_5
    group.inputs[4].default_value = 0.75
    #Socket_7
    group.inputs[5].default_value = 50.0
    #Socket_8
    group.inputs[6].default_value = 50.0





    #Set locations
    group_output_1.location = (956.3624267578125, 14.520790100097656)
    group_input_1.location = (-843.720947265625, -2.384185791015625e-06)
    group.location = (-101.47148895263672, -100.38209533691406)

    #Set dimensions
    group_output_1.width, group_output_1.height = 140.0, 100.0
    group_input_1.width, group_input_1.height = 140.0, 100.0
    group.width, group.height = 222.3646240234375, 100.0

    #initialize smooth_draw links
    #group.Geometry -> group_output_1.Geometry
    smooth_draw.links.new(group.outputs[0], group_output_1.inputs[0])
    #group_input_1.Geometry -> group.Curve
    smooth_draw.links.new(group_input_1.outputs[0], group.inputs[0])
    #group_input_1.Radius -> group.Radius
    smooth_draw.links.new(group_input_1.outputs[1], group.inputs[1])
    #group_input_1.Density -> group.Density
    smooth_draw.links.new(group_input_1.outputs[2], group.inputs[2])
    #group_input_1.Iterations -> group.Iterations
    smooth_draw.links.new(group_input_1.outputs[3], group.inputs[3])
    return smooth_draw

smooth_draw = smooth_draw_node_group()