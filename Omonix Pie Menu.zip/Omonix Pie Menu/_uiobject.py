# -*- coding: utf-8 -*-
# --------------------------------------------------------------------------
# File: _uiobject.py (STABLE 2.0.1 - MatColeX Info Pop-up)
# --------------------------------------------------------------------------

import bpy


# --- 1. Quick FX Pop-up Menu ---
class OMONIX_MT_SmoothyMenu(bpy.types.Menu):
    """Pop-up menu for Quick FX (Smooth Mesh and Smooth Curve)."""
    bl_idname = "OMONIX_MT_smoothy_menu"
    bl_label = "Quick FX Tools" 

    def draw(self, context):
        layout = self.layout
        icon_name = 'SMOOTHCURVE'
        
        layout.operator("omonix.shaper_smooth_mesh", text="Smooth Mesh (GeoNode)", icon=icon_name)
        layout.operator("omonix.shaper_smooth_curve", text="Smooth Curve (GeoNode)", icon=icon_name)


# --- 2. Quick FX Caller Operator ---
class OMONIX_OT_CallSmoothyMenu(bpy.types.Operator):
    """Displays the pop-up menu for Quick FX."""
    bl_idname = "omonix.call_smoothy_menu"
    bl_label = "Quick FX"
    bl_description = "Quick FX tools (Mesh/Curve Smoothing)"

    def execute(self, context):
        bpy.ops.wm.call_menu(name=OMONIX_MT_SmoothyMenu.bl_idname)
        return {'FINISHED'}


# --- 3. MatColeX Operator ---
class OMONIX_OT_CallMaterialListMenu(bpy.types.Operator):
    """Open MatColeX predefined panel directly."""
    bl_idname = "omonix.call_material_list_menu"
    bl_label = "MatColeX"
    bl_description = "Open the predefined MatColeX panel in the Sidebar (N Panel)"

    def execute(self, context):
        try:
             # Try to call the MatColeX-Pro panel
             bpy.ops.wm.call_panel(name="MC_PT_main_panel")
        except:
             # --- INI PERBAIKANNYA ---
             # Failed? Call the new info pop-up
             bpy.ops.omonix.matcolex_missing('INVOKE_DEFAULT')
        return {'FINISHED'}

# --- NEW MATCOLEX INFO POP-UP OPERATOR ---
class OMONIX_OT_MatColeXMissing(bpy.types.Operator):
    """Shows a pop-up dialog with information on how to get MatColeX."""
    bl_idname = "omonix.matcolex_missing"
    bl_label = "MatColeX-Pro Not Found"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        # Call the pop-up dialog
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.label(text="MatColeX-Pro addon is not installed or enabled.", icon='ERROR')
        layout.label(text="Please ensure the addon is active in Preferences.")
        layout.separator()
        layout.label(text="Where to get it:")
        
        box = layout.box()
        col = box.column(align=True)
        col.label(text="MatColeX (Free): Blender Extension", icon='BLENDER')
        col.label(text="MatColeX-Pro (Paid): Superhivemarket.com", icon='URL')

    def execute(self, context):
        # This is just a dialog operator, it does nothing on execute
        return {'FINISHED'}


# ============================================================
# APPLY TOOLS (New "Others" Layout)
# ============================================================

class OMONIX_OT_ApplyAllTransforms(bpy.types.Operator):
    """Applies Location, Rotation, and Scale (All Transforms)."""
    bl_idname = "omonix.apply_all_transforms"
    bl_label = "All Transforms (Loc, Rot, Scale)"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply Location, Rotation, and Scale (Ctrl+A)"
    def execute(self, context):
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        self.report({'INFO'}, "All Transforms applied.")
        return {'FINISHED'}

class OMONIX_OT_ApplyVisualGeometry(bpy.types.Operator):
    """Applies Visual Geometry to Mesh."""
    bl_idname = "omonix.apply_visual_geometry"
    bl_label = "Visual Geometry to Mesh"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply modifiers and shape keys to mesh data"
    def execute(self, context):
        bpy.ops.object.visual_transform_apply()
        self.report({'INFO'}, "Visual Geometry applied.")
        return {'FINISHED'}

class OMONIX_OT_MakeInstancesReal(bpy.types.Operator):
    """Applies Make Instances Real (Convert)."""
    bl_idname = "omonix.make_instances_real"
    bl_label = "Make Instances Real"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Convert geometry instances (like collections) to real objects"
    def execute(self, context):
        bpy.ops.object.duplicates_make_real()
        self.report({'INFO'}, "Instances made real.")
        return {'FINISHED'}
    
# --- "OTHERS" MENU (Contains only 2 items) ---
class OMONIX_MT_ApplyToolsMenu(bpy.types.Menu):
    """Compact menu for other Apply tools (Visual Geometry, Instances)."""
    bl_idname = "OMONIX_MT_apply_tools_menu"
    bl_label = "Other Apply Tools"

    def draw(self, context):
        layout = self.layout
        layout.operator(OMONIX_OT_ApplyVisualGeometry.bl_idname, icon='SNAP_PEEL_OBJECT')
        layout.operator(OMONIX_OT_MakeInstancesReal.bl_idname, icon='GROUP')

# --- Caller Operator (Not used by Pie, but functional) ---
class OMONIX_OT_CallApplyTools(bpy.types.Operator):
    """Displays the pop-up menu for Other Apply Tools."""
    bl_idname = "omonix.apply_tools"
    bl_label = "Other Apply Tools"
    bl_options = {'INTERNAL'}
    bl_description = "Menu for other Apply actions (Visual Geometry, Instances)"

    def execute(self, context):
        bpy.ops.wm.call_menu(name=OMONIX_MT_ApplyToolsMenu.bl_idname)
        return {'FINISHED'}


# --- LIST OF CLASSES FOR REGISTRATION ---
classes_to_register = (
    OMONIX_MT_SmoothyMenu,
    OMONIX_OT_CallSmoothyMenu,
    OMONIX_OT_CallMaterialListMenu,
    
    OMONIX_OT_MatColeXMissing, # <-- TAMBAHKAN OPERATOR BARU
    
    OMONIX_OT_ApplyAllTransforms,
    OMONIX_OT_ApplyVisualGeometry,
    OMONIX_OT_MakeInstancesReal,
    OMONIX_MT_ApplyToolsMenu,
    OMONIX_OT_CallApplyTools,
)