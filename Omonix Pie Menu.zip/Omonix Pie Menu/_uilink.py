# -*- coding: utf-8 -*-
# --------------------------------------------------------------------------
# File: _uilink.py (DIPERBARUI: Tambah Submenu Transfer Mesh Data)
# --------------------------------------------------------------------------
import bpy


# ============================================================
# 1. MENU BARU: Transfer Mesh Data
# ============================================================
class OMONIX_MT_TransferMeshMenu(bpy.types.Menu):
    """Sub-menu untuk mentransfer tipe data mesh spesifik."""
    bl_idname = "OMONIX_MT_transfer_mesh_menu"
    bl_label = "Transfer Mesh Data"

    def draw(self, context):
        layout = self.layout
        
        # 1. Vertex Groups (menggunakan object.data_transfer)
        op_vgroup = layout.operator("object.data_transfer", text="Transfer Vertex Groups", icon='GROUP_VERTEX')
        op_vgroup.data_type = 'VGROUP_WEIGHTS'

        # 2. UV Maps (menggunakan object.data_transfer)
        op_uv = layout.operator("object.data_transfer", text="Transfer UV Maps", icon='UV_DATA')
        op_uv.data_type = 'UV'

        # 3. Vertex Colors (menggunakan object.data_transfer)
        op_vcol = layout.operator("object.data_transfer", text="Transfer Vertex Colors", icon='VPAINT_HLT')
        op_vcol.data_type = 'VCOL'
        
        # 4. Shape Keys (menggunakan operator terpisah)
        layout.operator("object.shape_key_transfer", text="Transfer Shape Keys", icon='SHAPEKEY_DATA')
        
        layout.separator()
        
        # 5. Operator generik (membuka panel F9)
        layout.operator("object.data_transfer", text="Transfer Data (Panel)...", icon='PROPERTIES')


# ============================================================
# 2. MENU "OTHERS" (Menu Induk)
# ============================================================
class OMONIX_MT_LinkOthersMenu(bpy.types.Menu):
    """Menampilkan alat linking objek lainnya dalam menu pop-up."""
    bl_idname = "OMONIX_MT_link_others_menu"
    bl_label = "Other Link Tools"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        
        # 1. Link Materials
        op_mat = layout.operator("object.make_links_data", text="Link Materials", icon='MATERIAL_DATA')
        op_mat.type = 'MATERIALS'
        
        # --- PERUBAHAN DI SINI ---
        # 2. Transfer Mesh Data (Sub-menu)
        # Memanggil menu baru yang kita definisikan di atas
        layout.menu(OMONIX_MT_TransferMeshMenu.bl_idname, icon='TRANSFER_DATA')
        # --- AKHIR PERUBAHAN ---

        # 3. Link Object Data (Mesh/Curve/etc.)
        op_data = layout.operator("object.make_links_data", text="Link Object Data", icon='OBJECT_DATA')
        op_data.type = 'OBDATA'
        
        # 4. Link to Collection
        layout.operator("object.link_to_collection", text="Link to Collection", icon='COLLECTION_NEW')
        
        layout.separator()

        # 5. Link Animation Data
        op_anim = layout.operator("object.make_links_data", text="Link Animation Data", icon='ANIM')
        op_anim.type = 'ANIMATION'
        
        # 6. Link Fonts
        op_font = layout.operator("object.make_links_data", text="Link Fonts to Text", icon='FILE_FONT')
        op_font.type = 'FONT'


# ============================================================
# Registration
# ============================================================
classes_to_register = (
    OMONIX_MT_TransferMeshMenu, # <-- Daftarkan Menu Baru
    OMONIX_MT_LinkOthersMenu,   # Daftarkan Menu Induk
)