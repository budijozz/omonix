# File: _uiempty.py (Translated)

import bpy

# --- 1. OPERATOR A: Apply All Modifiers (Quick Mesh) ---
class OMONIX_OT_ApplyAllModifiers(bpy.types.Operator):
    """Applies all Modifiers on the Active Object (Quick Tools Command)."""
    bl_idname = "omonix.apply_all_modifiers"
    bl_label = "Apply All Modifiers" # Changed label to be more explicit
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Applies all modifiers and converts the object to a Mesh."
    
    @classmethod
    def poll(cls, context): 
        # Only allow if an active object is selected
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object selected.")
            return {'CANCELLED'}
        
        # Ensure the object is in Object Mode
        if obj.mode != 'OBJECT':
             bpy.ops.object.mode_set(mode='OBJECT')

        try:
            # The 'convert' command (target='MESH') applies all geometry-based modifiers
            bpy.ops.object.convert(target='MESH')
            self.report({'INFO'}, f"All Modifiers applied/Object converted to Mesh: '{obj.name}'.")
        except RuntimeError as e:
            self.report({'ERROR'}, f"Failed to apply/convert modifiers on '{obj.name}': {e.args[0]}")
            return {'CANCELLED'}
            
        return {'FINISHED'}


# --- 2. OPERATOR B: QRemeshify (Moved from _uishaper.py) ---
class OMONIX_OT_IntegratedQRemesh(bpy.types.Operator):
    bl_idname = "omonix.shaper_qremesh" # Retain old ID for compatibility with Pie Menu
    bl_label = "Quad Remesh" 
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Calls the external QRemeshify operator for quad topology generation."
    
    @classmethod
    def poll(cls, context):
        # Checks for the presence of the external QRemeshify addon
        return hasattr(bpy.ops, 'qremeshify') and context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        # Calls the external QRemeshify operator
        try:
            bpy.ops.qremeshify.remesh('INVOKE_DEFAULT') 
            self.report({'INFO'}, "QRemeshify operator invoked.")
        except RuntimeError as e:
            self.report({'ERROR'}, f"Failed to invoke QRemeshify: {e.args[0]}. Is the mesh valid?")
            return {'CANCELLED'}
            
        return {'FINISHED'}


# --- LIST OF CLASSES FOR REGISTRATION ---
classes_to_register = (
    OMONIX_OT_ApplyAllModifiers,
    OMONIX_OT_IntegratedQRemesh,
)