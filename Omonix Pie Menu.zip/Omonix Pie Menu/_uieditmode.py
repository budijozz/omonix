# File: _uieditmode.py (DIPERBARUI: Tambah Operator Kontekstual)
import bpy
from mathutils import Vector 
# Ray-Cast utilities import
from bpy_extras.view3d_utils import region_2d_to_vector_3d, region_2d_to_location_3d

# ======================================================================
# == 0. PROXY OPERATOR FOR SELECT LINKED (Retained and Translated) ==
# ======================================================================

class OMONIX_OT_SelectLinkedType(bpy.types.Operator):
    """Selects linked elements based on a specific type."""
    bl_idname = "omonix.select_linked_type"
    bl_label = "Select Linked Type"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Selects linked geometry based on Material, Seam, Sharp, or UVs."
    
    select_type: bpy.props.EnumProperty(
        items=[
            ('MATERIAL', "Material", ""),
            ('SEAM', "Seam", ""),
            ('SHARP', "Sharp", ""),
            ('UV', "UVs", ""),
        ]
    )

    def execute(self, context):
        if context.mode != 'EDIT_MESH':
             self.report({'WARNING'}, "Please enter Mesh Edit Mode.")
             return {'CANCELLED'}
        
        # The delimit parameter must be a set {}
        bpy.ops.mesh.select_linked(delimit={self.select_type})
        self.report({'INFO'}, f"Select Linked by {self.select_type} executed.")
        return {'FINISHED'}

# ======================================================================
# == 1. MAIN OPERATOR FOR SPLIT TOOLS (Retained) ==
# ======================================================================

class OMONIX_OT_SmartSeparate(bpy.types.Operator):
    """
    Separates (Selected), returns to Object Mode, selects the new object, 
    and calls Place Helper, jumping to the mouse pointer position.
    """
    bl_idname = "omonix.smart_separate"
    bl_label = "Separate (Smart Place)"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Separate selected elements, switch to Object Mode, and start move/snap at mouse location."

    def invoke(self, context, event):
        active_obj = context.active_object
        if not active_obj or active_obj.mode != 'EDIT_MESH':
            self.report({'WARNING'}, "Please select a mesh in Edit Mode.")
            return {'CANCELLED'}
        
        # Store the original object before separation
        original_obj = active_obj
        
        # --- 1. RAY CAST LOGIC (FINDING 3D POSITION UNDER MOUSE) ---
        target_loc = context.scene.cursor.location.copy()
        
        region = context.region
        rv3d = context.region_data
        
        if region and rv3d:
            mouse_pos = (event.mouse_region_x, event.mouse_region_y)
            vec = region_2d_to_vector_3d(region, rv3d, mouse_pos)
            ray_origin = region_2d_to_location_3d(region, rv3d, mouse_pos, vec)
            
            # Ray-cast against all objects in the scene
            result, location, normal, index, obj, matrix = context.scene.ray_cast(context.view_layer.depsgraph, ray_origin, vec)
            if result:
                target_loc = location
        
        # 2. SEPARATE (mesh.separate)
        try:
            # Separate only selected
            bpy.ops.mesh.separate(type='SELECTED')
        except RuntimeError:
            self.report({'WARNING'}, "No selected elements to separate.")
            return {'CANCELLED'}
            
        # 3. Return to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # 4. Find the New Object
        # Use list(context.selected_objects) to get all selected objects after separation
        new_obj = next((obj for obj in context.selected_objects if obj != original_obj), None)
        
        if new_obj:
            # Deselect the original and set the new object as active
            original_obj.select_set(False)
            context.view_layer.objects.active = new_obj
            new_obj.select_set(True)

            # 5. CALCULATE MOVEMENT VECTOR (DELTA)
            current_loc = new_obj.matrix_world.translation
            delta_vector = target_loc - current_loc
            
            # 6. JUMP OBJECT & START INTERACTIVE MOVE SESSION
            move_args = {'value': delta_vector, 'orient_type': 'GLOBAL'}

            try:
                # Instant Jump (EXEC_DEFAULT)
                bpy.ops.transform.translate('EXEC_DEFAULT', **move_args) 
                # Interactive Session from the new location
                bpy.ops.ph.move_object('INVOKE_DEFAULT') 
                self.report({'INFO'}, "Separation complete. Place Helper called.")
            except (AttributeError, RuntimeError):
                # Fallback to Move tool
                self.report({'INFO'}, "Separation complete. Place Helper not found, running default Move tool.")
                bpy.ops.transform.translate('INVOKE_DEFAULT', **move_args)
        else:
            self.report({'WARNING'}, "Failed to find the new object after separation.")
            return {'CANCELLED'}
            
        return {'FINISHED'}

    def execute(self, context): return {'FINISHED'} 


# ======================================================================
# == 2. CALLER OPERATORS FOR DROPDOWN MENUS (Retained) ==
# ======================================================================
class OMONIX_OT_CallSelectLinkedMenu(bpy.types.Operator):
    bl_idname = "omonix.call_select_linked_menu"; bl_label = "Select Linked"; bl_options = {'INTERNAL'}
    def execute(self, context): bpy.ops.wm.call_menu(name="OMONIX_MT_select_linked_menu"); return {'FINISHED'}
class OMONIX_OT_CallEdgeToolsMenu(bpy.types.Operator):
    bl_idname = "omonix.call_edge_tools_menu"; bl_label = "Edge Tools"; bl_options = {'INTERNAL'}
    def execute(self, context): bpy.ops.wm.call_menu(name="OMONIX_MT_edge_tools_menu"); return {'FINISHED'}
class OMONIX_OT_CallLoopToolsMenu(bpy.types.Operator):
    bl_idname = "omonix.call_loop_tools_menu"; bl_label = "Loop Tools"; bl_options = {'INTERNAL'}
    def execute(self, context): bpy.ops.wm.call_menu(name="OMONIX_MT_loop_tools_menu"); return {'FINISHED'}


# ======================================================================
# == 2.7. WRAPPER OPERATORS (Subdivide, Bevel, Crease, Merge) ==
# ======================================================================

class OMONIX_OT_InvokeSubdivide(bpy.types.Operator):
    bl_idname = "omonix.invoke_subdivide"; bl_label = "Subdivide"
    bl_description = "Calls mesh subdivide and keeps the adjustment panel open"
    bl_options = {'INTERNAL'}
    def execute(self, context):
        bpy.ops.mesh.subdivide('INVOKE_DEFAULT'); return {'FINISHED'}

# --- OPERATOR BARU UNTUK VERTEX/EDGE MODE ---

class OMONIX_OT_VertexBevel(bpy.types.Operator):
    bl_idname = "omonix.vertex_bevel"; bl_label = "Bevel Verts"
    bl_description = "Bevel selected vertices and show panel"
    bl_options = {'INTERNAL'}
    def execute(self, context):
        bpy.ops.mesh.bevel('INVOKE_DEFAULT', affect='VERTICES'); return {'FINISHED'}

class OMONIX_OT_EdgeBevel(bpy.types.Operator):
    bl_idname = "omonix.edge_bevel"; bl_label = "Bevel Edges"
    bl_description = "Bevel selected edges and show panel"
    bl_options = {'INTERNAL'}
    def execute(self, context):
        bpy.ops.mesh.bevel('INVOKE_DEFAULT', affect='EDGES'); return {'FINISHED'}

class OMONIX_OT_EdgeCrease(bpy.types.Operator):
    bl_idname = "omonix.edge_crease"; bl_label = "Edge Crease"
    bl_description = "Adjust edge crease and show panel"
    bl_options = {'INTERNAL'}
    def execute(self, context):
        bpy.ops.transform.edge_crease('INVOKE_DEFAULT'); return {'FINISHED'}

class OMONIX_OT_MergeByDistance(bpy.types.Operator):
    bl_idname = "omonix.merge_by_distance"; bl_label = "Merge By Distance"
    bl_description = "Merge vertices by distance and show panel"
    bl_options = {'INTERNAL'}
    def execute(self, context):
        # 'remove_doubles' adalah nama internal untuk 'Merge by Distance'
        bpy.ops.mesh.remove_doubles('INVOKE_DEFAULT'); return {'FINISHED'}


# ======================================================================
# == 3. DROPDOWN MENU DEFINITIONS (Icon Fix) ==
# ======================================================================

class OMONIX_MT_SelectLinkedMenu(bpy.types.Menu):
    bl_idname = "OMONIX_MT_select_linked_menu"
    bl_label = "Select Linked"
    def draw(self, context):
        layout = self.layout
        op_id = OMONIX_OT_SelectLinkedType.bl_idname
        op = layout.operator(op_id, text="Seam", icon='SELECT_SET'); op.select_type = 'SEAM'
        op = layout.operator(op_id, text="Sharp", icon='STICKY_UVS_LOC'); op.select_type = 'SHARP'
        op = layout.operator(op_id, text="Material", icon='MATERIAL'); op.select_type = 'MATERIAL'
        op = layout.operator(op_id, text="UVs", icon='UV_DATA'); op.select_type = 'UV'
        layout.separator()
        layout.operator("mesh.select_linked", text="Normal (All)", icon='LINKED')

class OMONIX_MT_EdgeToolsMenu(bpy.types.Menu):
    bl_idname = "OMONIX_MT_edge_tools_menu"
    bl_label = "Edge Tools"
    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.mark_seam", text="Mark Seam", icon='SELECT_SET')
        layout.operator("mesh.clear_seam", text="Clear Seam", icon='SELECT_SET') 
        layout.separator()
        layout.operator("mesh.mark_sharp", text="Mark Sharp", icon='STICKY_UVS_LOC')
        layout.operator("mesh.clear_sharp", text="Clear Sharp", icon='STICKY_UVS_LOC') 
        layout.separator() 
        layout.operator("mesh.dissolve_edges", text="Dissolve Edge", icon='X')
        op_delete = layout.operator("mesh.delete", text="Delete Edge", icon='REMOVE')
        op_delete.type = 'EDGE'
        layout.operator("mesh.relax", text="Relax (Mesh)", icon='MOD_SMOOTH')
        layout.separator()
        layout.operator("mesh.select_alternate", text="Checker Deselect", icon='MOD_MASK') 
        layout.operator("mesh.select_random", text="Select Random", icon='SELECT_SET') 

class OMONIX_MT_LoopToolsMenu(bpy.types.Menu):
    bl_idname = "OMONIX_MT_loop_tools_menu"; bl_label = "Loop Tools (Meshtools)"
    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.looptools_bridge", text="Bridge", icon='MOD_SUBSURF')
        layout.operator("mesh.looptools_circle", text="Circle", icon='MESH_CIRCLE')
        layout.operator("mesh.looptools_flatten", text="Flatten", icon='AXIS_SIDE')
        # --- PERBAIKAN DARI SEBELUMNYA ---
        layout.operator("mesh.looptools_space", text="Space", icon='AXIS_TOP') # Menggunakan 'AXIS_TOP'

# Menu Extrude lama
class OMONIX_MT_ExtrudeToolsMenu(bpy.types.Menu):
    bl_idname = "OMONIX_MT_extrude_tools_menu"; bl_label = "Extrude Tools (Old)"
    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.extrude_region", text="Extrude Face (Default)", icon='PLUS') 
        layout.operator("mesh.extrude_along_normals", text="Face Along Normal", icon='CON_FOLLOWPATH')
        layout.operator("mesh.extrude_individual_faces", text="Individual Face", icon='AUTOMERGE_ON')
        layout.operator("mesh.extrude_manifold", text="Manifold", icon='SNAP_FACE')
        layout.operator("mesh.spin", text="Spin", icon='SNAP_NORMAL')


# ======================================================================
# == 4. REGISTRATION LIST (Diperbarui) ==
# ======================================================================

classes_to_register = (
    OMONIX_OT_SelectLinkedType, 
    OMONIX_OT_SmartSeparate,
    OMONIX_OT_CallSelectLinkedMenu,
    OMONIX_OT_CallEdgeToolsMenu,
    OMONIX_OT_CallLoopToolsMenu,
    
    OMONIX_OT_InvokeSubdivide,
    
    # --- TAMBAHAN BARU ---
    OMONIX_OT_VertexBevel,
    OMONIX_OT_EdgeBevel,
    OMONIX_OT_EdgeCrease,
    OMONIX_OT_MergeByDistance,
    # --- AKHIR TAMBAHAN ---
    
    OMONIX_MT_ExtrudeToolsMenu, 
    OMONIX_MT_SelectLinkedMenu,
    OMONIX_MT_EdgeToolsMenu,
    OMONIX_MT_LoopToolsMenu,
)