import bpy, mathutils

#initialize kocoxalus node group
def kocoxalus_node_group():
    kocoxalus = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "KocoxAlus")

    # [API FIX]: Baris color_tag dan default_group_node_width dihapus
    kocoxalus.description = ""
    
    #kocoxalus interface
    #Socket Geometry
    geometry_socket = kocoxalus.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Curve
    curve_socket = kocoxalus.interface.new_socket(name = "Curve", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    curve_socket.attribute_domain = 'POINT'

    #Socket Radius
    radius_socket = kocoxalus.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
    radius_socket.default_value = 20.0
    radius_socket.min_value = 0.0
    radius_socket.max_value = 3.4028234663852886e+38
    radius_socket.subtype = 'DISTANCE'
    radius_socket.attribute_domain = 'POINT'

    #Socket Density
    density_socket = kocoxalus.interface.new_socket(name = "Density", in_out='INPUT', socket_type = 'NodeSocketFloat')
    density_socket.default_value = 2.2999963760375977
    density_socket.min_value = 0.009999999776482582
    density_socket.max_value = 3.4028234663852886e+38
    density_socket.subtype = 'NONE'
    density_socket.attribute_domain = 'POINT'

    #Socket Iterations
    iterations_socket = kocoxalus.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
    iterations_socket.default_value = 5
    iterations_socket.min_value = 0
    iterations_socket.max_value = 2147483647
    iterations_socket.subtype = 'NONE'
    iterations_socket.attribute_domain = 'POINT'

    #Socket Weight
    weight_socket = kocoxalus.interface.new_socket(name = "Weight", in_out='INPUT', socket_type = 'NodeSocketFloat')
    weight_socket.default_value = 0.75
    weight_socket.min_value = 0.0
    weight_socket.max_value = 1.0
    weight_socket.subtype = 'FACTOR'
    weight_socket.attribute_domain = 'POINT'

    #Panel ☛ Want Detail Voxel  ☚
    __want_detail_voxel____panel = kocoxalus.interface.new_panel("☛ Want Detail Voxel  ☚")
    #Socket JML VOXEL AVM
    jml_voxel_avm_socket = kocoxalus.interface.new_socket(name = "JML VOXEL AVM", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __want_detail_voxel____panel)
    jml_voxel_avm_socket.default_value = 50.0
    jml_voxel_avm_socket.min_value = 0.0
    jml_voxel_avm_socket.max_value = 3.4028234663852886e+38
    jml_voxel_avm_socket.subtype = 'NONE'
    jml_voxel_avm_socket.attribute_domain = 'POINT'

    #Socket jml Voxel BVM
    jml_voxel_bvm_socket = kocoxalus.interface.new_socket(name = "jml Voxel BVM", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __want_detail_voxel____panel)
    jml_voxel_bvm_socket.default_value = 50.0
    jml_voxel_bvm_socket.min_value = 0.0
    jml_voxel_bvm_socket.max_value = 3.4028234663852886e+38
    jml_voxel_bvm_socket.subtype = 'NONE'
    jml_voxel_bvm_socket.attribute_domain = 'POINT'



    #initialize kocoxalus nodes
    #node Group Output
    group_output = kocoxalus.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Realize Instances
    realize_instances = kocoxalus.nodes.new("GeometryNodeRealizeInstances")
    realize_instances.name = "Realize Instances"
    #Selection
    realize_instances.inputs[1].default_value = True
    #Realize All
    realize_instances.inputs[2].default_value = True
    #Depth
    realize_instances.inputs[3].default_value = 0

    #node Set Shade Smooth
    set_shade_smooth = kocoxalus.nodes.new("GeometryNodeSetShadeSmooth")
    set_shade_smooth.name = "Set Shade Smooth"
    set_shade_smooth.domain = 'FACE'
    #Selection
    set_shade_smooth.inputs[1].default_value = True
    #Shade Smooth
    set_shade_smooth.inputs[2].default_value = True

    #node Curve to Mesh
    curve_to_mesh = kocoxalus.nodes.new("GeometryNodeCurveToMesh")
    curve_to_mesh.name = "Curve to Mesh"
    #Fill Caps
    curve_to_mesh.inputs[2].default_value = True

    #node Mesh to Volume
    mesh_to_volume = kocoxalus.nodes.new("GeometryNodeMeshToVolume")
    mesh_to_volume.name = "Mesh to Volume"
    mesh_to_volume.resolution_mode = 'VOXEL_AMOUNT'
    #Interior Band Width
    mesh_to_volume.inputs[4].default_value = 1.0

    #node Trim Curve
    trim_curve = kocoxalus.nodes.new("GeometryNodeTrimCurve")
    trim_curve.name = "Trim Curve"
    trim_curve.mode = 'FACTOR'
    #Selection
    trim_curve.inputs[1].default_value = True
    #Start
    trim_curve.inputs[2].default_value = 0.0
    #End
    trim_curve.inputs[3].default_value = 1.0

    #node Volume to Mesh
    volume_to_mesh = kocoxalus.nodes.new("GeometryNodeVolumeToMesh")
    volume_to_mesh.name = "Volume to Mesh"
    volume_to_mesh.resolution_mode = 'VOXEL_AMOUNT'
    #Threshold
    volume_to_mesh.inputs[3].default_value = 0.25
    #Adaptivity
    volume_to_mesh.inputs[4].default_value = 0.0

    #node Curve Circle
    curve_circle = kocoxalus.nodes.new("GeometryNodeCurvePrimitiveCircle")
    curve_circle.name = "Curve Circle"
    curve_circle.mode = 'RADIUS'
    #Resolution
    curve_circle.inputs[0].default_value = 50

    #node Blur Attribute
    blur_attribute = kocoxalus.nodes.new("GeometryNodeBlurAttribute")
    blur_attribute.name = "Blur Attribute"
    blur_attribute.data_type = 'FLOAT_VECTOR'

    #node Group Input
    group_input = kocoxalus.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Set Position
    set_position = kocoxalus.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"
    #Selection
    set_position.inputs[1].default_value = True
    #Offset
    set_position.inputs[3].default_value = (0.0, 0.0, 0.0)

    #node Position
    position = kocoxalus.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"





    #Set locations
    group_output.location = (1089.9268798828125, -36.449546813964844)
    realize_instances.location = (248.925048828125, 48.92664337158203)
    set_shade_smooth.location = (773.2301635742188, 71.06795501708984)
    curve_to_mesh.location = (-369.1913146972656, 48.039817810058594)
    mesh_to_volume.location = (-197.725341796875, 51.66999053955078)
    trim_curve.location = (-613.9948120117188, 152.1015167236328)
    volume_to_mesh.location = (39.99596405029297, 52.008811950683594)
    curve_circle.location = (-611.8809204101562, -24.48720932006836)
    blur_attribute.location = (288.41021728515625, -107.44374084472656)
    group_input.location = (-934.8941650390625, -152.30340576171875)
    set_position.location = (548.7305908203125, -86.2169189453125)
    position.location = (14.493141174316406, -238.6593475341797)

    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    realize_instances.width, realize_instances.height = 140.0, 100.0
    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
    mesh_to_volume.width, mesh_to_volume.height = 200.0, 100.0
    trim_curve.width, trim_curve.height = 140.0, 100.0
    volume_to_mesh.width, volume_to_mesh.height = 170.0, 100.0
    curve_circle.width, curve_circle.height = 140.0, 100.0
    blur_attribute.width, blur_attribute.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    set_position.width, set_position.height = 140.0, 100.0
    position.width, position.height = 140.0, 100.0

    #initialize kocoxalus links
    #volume_to_mesh.Mesh -> realize_instances.Geometry
    kocoxalus.links.new(volume_to_mesh.outputs[0], realize_instances.inputs[0])
    #curve_circle.Curve -> curve_to_mesh.Profile Curve
    kocoxalus.links.new(curve_circle.outputs[0], curve_to_mesh.inputs[1])
    #mesh_to_volume.Volume -> volume_to_mesh.Volume
    kocoxalus.links.new(mesh_to_volume.outputs[0], volume_to_mesh.inputs[0])
    #set_position.Geometry -> set_shade_smooth.Geometry
    kocoxalus.links.new(set_position.outputs[0], set_shade_smooth.inputs[0])
    #curve_to_mesh.Mesh -> mesh_to_volume.Mesh
    kocoxalus.links.new(curve_to_mesh.outputs[0], mesh_to_volume.inputs[0])
    #blur_attribute.Value -> set_position.Position
    kocoxalus.links.new(blur_attribute.outputs[0], set_position.inputs[2])
    #position.Position -> blur_attribute.Value
    kocoxalus.links.new(position.outputs[0], blur_attribute.inputs[0])
    #realize_instances.Geometry -> set_position.Geometry
    kocoxalus.links.new(realize_instances.outputs[0], set_position.inputs[0])
    #trim_curve.Curve -> curve_to_mesh.Curve
    kocoxalus.links.new(trim_curve.outputs[0], curve_to_mesh.inputs[0])
    #set_shade_smooth.Geometry -> group_output.Geometry
    kocoxalus.links.new(set_shade_smooth.outputs[0], group_output.inputs[0])
    #group_input.Radius -> curve_circle.Radius
    kocoxalus.links.new(group_input.outputs[1], curve_circle.inputs[4])
    #group_input.Curve -> trim_curve.Curve
    kocoxalus.links.new(group_input.outputs[0], trim_curve.inputs[0])
    #group_input.Density -> mesh_to_volume.Density
    kocoxalus.links.new(group_input.outputs[2], mesh_to_volume.inputs[1])
    #group_input.Iterations -> blur_attribute.Iterations
    kocoxalus.links.new(group_input.outputs[3], blur_attribute.inputs[1])
    #group_input.jml Voxel BVM -> volume_to_mesh.Voxel Amount
    kocoxalus.links.new(group_input.outputs[6], volume_to_mesh.inputs[2])
    #group_input.Weight -> blur_attribute.Weight
    kocoxalus.links.new(group_input.outputs[4], blur_attribute.inputs[2])
    #group_input.JML VOXEL AVM -> mesh_to_volume.Voxel Amount
    kocoxalus.links.new(group_input.outputs[5], mesh_to_volume.inputs[3])
    return kocoxalus

kocoxalus = kocoxalus_node_group()

#initialize kocox_alus node group
def kocox_alus_node_group():
    kocox_alus = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "KOCOX ALUS")

    # [API FIX]: Baris color_tag dan default_group_node_width dihapus
    kocox_alus.description = ""
    
    kocox_alus.is_modifier = True

    #kocox_alus interface
    #Socket Geometry
    geometry_socket_1 = kocox_alus.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_2 = kocox_alus.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_2.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_3 = kocox_alus.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_3.attribute_domain = 'POINT'

    #Panel ☛ Kocox Alus < 100 || details > 150☚
    __kocox_alus___100____details___150__panel = kocox_alus.interface.new_panel("☛ Kocox Alus < 100 || details > 150☚")
    #Socket Voxel AVM
    voxel_avm_socket = kocox_alus.interface.new_socket(name = "Voxel AVM", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __kocox_alus___100____details___150__panel)
    voxel_avm_socket.default_value = 100.0
    voxel_avm_socket.min_value = 0.0
    voxel_avm_socket.max_value = 3.4028234663852886e+38
    voxel_avm_socket.subtype = 'NONE'
    voxel_avm_socket.attribute_domain = 'POINT'

    #Socket voxel BVM
    voxel_bvm_socket = kocox_alus.interface.new_socket(name = "voxel BVM", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __kocox_alus___100____details___150__panel)
    voxel_bvm_socket.default_value = 20.0
    voxel_bvm_socket.min_value = 0.0
    voxel_bvm_socket.max_value = 3.4028234663852886e+38
    voxel_bvm_socket.subtype = 'NONE'
    voxel_bvm_socket.attribute_domain = 'POINT'


    #Panel ☛ Param Kocox ☚
    __param_kocox___panel = kocox_alus.interface.new_panel("☛ Param Kocox ☚")
    #Socket Mesh Density
    mesh_density_socket = kocox_alus.interface.new_socket(name = "Mesh Density", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __param_kocox___panel)
    mesh_density_socket.default_value = 31.0
    mesh_density_socket.min_value = 0.009999999776482582
    mesh_density_socket.max_value = 3.4028234663852886e+38
    mesh_density_socket.subtype = 'NONE'
    mesh_density_socket.attribute_domain = 'POINT'

    #Socket Radius
    radius_socket_1 = kocox_alus.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __param_kocox___panel)
    radius_socket_1.default_value = 0.29999980330467224
    radius_socket_1.min_value = 0.0
    radius_socket_1.max_value = 3.4028234663852886e+38
    radius_socket_1.subtype = 'DISTANCE'
    radius_socket_1.attribute_domain = 'POINT'

    #Socket Blur Iterations
    blur_iterations_socket = kocox_alus.interface.new_socket(name = "Blur Iterations", in_out='INPUT', socket_type = 'NodeSocketInt', parent = __param_kocox___panel)
    blur_iterations_socket.default_value = 8
    blur_iterations_socket.min_value = 0
    blur_iterations_socket.max_value = 2147483647
    blur_iterations_socket.subtype = 'NONE'
    blur_iterations_socket.attribute_domain = 'POINT'

    #Socket Blur Weight
    blur_weight_socket = kocox_alus.interface.new_socket(name = "Blur Weight", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = __param_kocox___panel)
    blur_weight_socket.default_value = 0.75
    blur_weight_socket.min_value = 0.0
    blur_weight_socket.max_value = 1.0
    blur_weight_socket.subtype = 'FACTOR'
    blur_weight_socket.attribute_domain = 'POINT'


    #Panel ☛ Macax Kocox ☚
    __macax_kocox___panel = kocox_alus.interface.new_panel("☛ Macax Kocox ☚")
    #Socket Material
    material_socket = kocox_alus.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = __macax_kocox___panel)
    material_socket.attribute_domain = 'POINT'



    #initialize kocox_alus nodes
    #node Group Output
    group_output_1 = kocox_alus.nodes.new("NodeGroupOutput")
    group_output_1.name = "Group Output"
    group_output_1.use_custom_color = True
    group_output_1.color = (0.1725490242242813, 0.0, 0.34117648005485535)
    group_output_1.is_active_output = True

    #node Group Input
    group_input_1 = kocox_alus.nodes.new("NodeGroupInput")
    group_input_1.name = "Group Input"
    group_input_1.use_custom_color = True
    group_input_1.color = (0.1725490242242813, 0.0, 0.34117648005485535)

    #node Group
    group = kocox_alus.nodes.new("GeometryNodeGroup")
    group.name = "Group"
    group.use_custom_color = True
    group.color = (0.1725490242242813, 0.0, 0.34117648005485535)
    group.node_tree = kocoxalus

    #node Set Material
    set_material = kocox_alus.nodes.new("GeometryNodeSetMaterial")
    set_material.name = "Set Material"
    set_material.use_custom_color = True
    set_material.color = (0.1725490242242813, 0.0, 0.34117648005485535)
    #Selection
    set_material.inputs[1].default_value = True

    #node Frame
    frame = kocox_alus.nodes.new("NodeFrame")
    frame.label = "Kocox Alus Carefully Crafted by Semangat Pagi Studio"
    frame.name = "Frame"
    frame.use_custom_color = True
    frame.color = (0.0, 0.0, 0.0)
    frame.label_size = 20
    frame.shrink = True




    #Set parents
    group_output_1.parent = frame
    group_input_1.parent = frame
    group.parent = frame
    set_material.parent = frame

    #Set locations
    group_output_1.location = (444.2157897949219, -201.5078582763672)
    group_input_1.location = (-311.4750671386719, -75.67605590820312)
    group.location = (-101.47148895263672, -100.38209533691406)
    set_material.location = (441.91424560546875, -78.90159606933594)
    frame.location = (0.0, 0.0)

    #Set dimensions
    group_output_1.width, group_output_1.height = 140.0, 100.0
    group_input_1.width, group_input_1.height = 140.0, 100.0
    group.width, group.height = 340.2314453125, 100.0
    set_material.width, set_material.height = 140.0, 100.0
    frame.width, frame.height = 953.8426513671875, 291.15728759765625

    #initialize kocox_alus links
    #set_material.Geometry -> group_output_1.Geometry
    kocox_alus.links.new(set_material.outputs[0], group_output_1.inputs[0])
    #group_input_1.Geometry -> group.Curve
    kocox_alus.links.new(group_input_1.outputs[0], group.inputs[0])
    #group.Geometry -> set_material.Geometry
    kocox_alus.links.new(group.outputs[0], set_material.inputs[0])
    #group_input_1.Material -> set_material.Material
    kocox_alus.links.new(group_input_1.outputs[7], set_material.inputs[2])
    #group_input_1.Radius -> group.Radius
    kocox_alus.links.new(group_input_1.outputs[4], group.inputs[1])
    #group_input_1.Mesh Density -> group.Density
    kocox_alus.links.new(group_input_1.outputs[3], group.inputs[2])
    #group_input_1.Blur Iterations -> group.Iterations
    kocox_alus.links.new(group_input_1.outputs[5], group.inputs[3])
    #group_input_1.Blur Weight -> group.Weight
    kocox_alus.links.new(group_input_1.outputs[6], group.inputs[4])
    #group_input_1.voxel BVM -> group.jml Voxel BVM
    kocox_alus.links.new(group_input_1.outputs[2], group.inputs[6])
    #group_input_1.Voxel AVM -> group.JML VOXEL AVM
    kocox_alus.links.new(group_input_1.outputs[1], group.inputs[5])
    return kocox_alus

kocox_alus = kocox_alus_node_group()