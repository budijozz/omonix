# File: _uishaper.py (FINAL STABIL - Smarty Edge Flow Fallback FIX)

import bpy
import os

# --- Helper Functions ---
def load_node_group_from_file(context, node_group_name, file_name, operator):
    """
    Checks and loads a node group from an external .py file located
    in the same directory as this script file.
    """
    if node_group_name in bpy.data.node_groups:
        return True
    try:
        # Get the directory path of the current script file (_uishaper.py)
        addon_path = os.path.dirname(os.path.realpath(__file__))
        file_path = os.path.join(addon_path, file_name)
        
        if os.path.exists(file_path):
            # Execute the external file (e.g., kocoxalus.py)
            bpy.utils.execfile(file_path)
            
            if node_group_name in bpy.data.node_groups:
                operator.report({'INFO'}, f"Node Group '{node_group_name}' loaded from {file_name}")
                return True
            else:
                operator.report({'ERROR'}, f"File '{file_name}' executed, but did not create node group '{node_group_name}'.")
                return False
        else:
            operator.report({'ERROR'}, f"Required file not found at: {file_path}")
            return False
    except Exception as e:
        # Use f-string for clear error message
        operator.report({'ERROR'}, f"Failed to execute {file_name}. Error: {e}")
        return {'CANCELLED'}

# This function applies the 'KOCOX ALUS' node group to the mesh
def apply_kocoxalus_to_mesh(operator, context):
    file_name = os.path.join("shaper_mesh", "kocoxalus.py")
    node_group_name = "KOCOX ALUS" 
    
    # 1. Load Node Group
    if not load_node_group_from_file(context, node_group_name, file_name, operator):
        return {'CANCELLED'}
    
    # 2. Prepare Object
    mesh_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
    if not mesh_objects:
        operator.report({'WARNING'}, "No mesh objects selected.")
        return {'CANCELLED'}

    # Join if more than one is selected
    if len(mesh_objects) > 1:
        context.view_layer.objects.active = mesh_objects[0]
        if context.object.mode != 'OBJECT':
             bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.join()
        
    final_obj = context.active_object
    
    # 3. Apply Modifier
    if final_obj and final_obj.type == 'MESH':
        mod = final_obj.modifiers.new(name="KocoxAlusSmooth", type='NODES')
        mod.node_group = bpy.data.node_groups.get(node_group_name)
        operator.report({'INFO'}, "Modifier 'KOCOX ALUS' applied.")
        return {'FINISHED'}
    else:
        operator.report({'ERROR'}, "Active object is not a mesh.")
        return {'CANCELLED'}


# === NEW SMOOTH CURVE LOGIC (SINGLE FILE) ===
def apply_omonix_curve_to_curve(operator, context):
    """Executes smooth_draw.py, then attempts to apply the resulting Geometry Node."""
    
    # Change path to point to 'shaper_curve/smooth_draw.py'
    file_path_relative_to_uishaper = os.path.join("shaper_curve", "smooth_draw.py")
    
    # 1. Object Validation
    active_obj = context.active_object
    if not active_obj or active_obj.type != 'CURVE':
        operator.report({'WARNING'}, "Please select an active Curve Object.")
        return {'CANCELLED'}

    # 2. Execute Script
    NODE_GROUP_NAME = "smooth_draw" 
    
    if not load_node_group_from_file(context, NODE_GROUP_NAME, file_path_relative_to_uishaper, operator):
        return {'CANCELLED'}
    
    # 3. EXPLICIT MODIFIER APPLICATION (FIX - MIMICKING KOCAXALUS)
    if NODE_GROUP_NAME in bpy.data.node_groups:
        mod = active_obj.modifiers.new(name="OmonixCurveSmooth", type='NODES')
        mod.node_group = bpy.data.node_groups.get(NODE_GROUP_NAME)
        operator.report({'INFO'}, f"Geometry Node Modifier '{NODE_GROUP_NAME}' applied.")
        return {'FINISHED'}
    else:
         operator.report({'WARNING'}, f"Node Group '{NODE_GROUP_NAME}' not found after execution. Modifier not applied.")
         return {'CANCELLED'}


# --- Shaper Operators ---
class OMONIX_OT_SmoothMesh(bpy.types.Operator):
    bl_idname = "omonix.shaper_smooth_mesh"; bl_label = "Smooth Mesh (GeoNode)"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply custom Geometry Node for mesh smoothing (Kocox Alus)."
    def execute(self, context): return apply_kocoxalus_to_mesh(self, context)

class OMONIX_OT_SmoothCurve(bpy.types.Operator):
    bl_idname = "omonix.shaper_smooth_curve"; bl_label = "Smooth Curve (GeoNode)"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply custom Geometry Node for curve smoothing (Omonix Curve)."
    def execute(self, context): return apply_omonix_curve_to_curve(self, context)

class OMONIX_OT_FastRelax(bpy.types.Operator):
    bl_idname = "omonix.shaper_fast_relax"; bl_label = "Relax Verts"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Relax vertices in Edit Mode (shortcut for mesh.relax)."
    @classmethod
    def poll(cls, context): return context.active_object and context.active_object.type == 'MESH'
    def execute(self, context):
        initial_mode = context.object.mode
        
        if initial_mode != 'EDIT': bpy.ops.object.mode_set(mode='EDIT')
        
        try: 
            bpy.ops.mesh.relax('INVOKE_DEFAULT')
            self.report({'INFO'}, "Relax Vertices operator called.")
        except RuntimeError as e: 
             self.report({'ERROR'}, f"Failed to relax: {e}. Ensure there is a selection or valid object.")
             
        if context.object.mode != initial_mode: bpy.ops.object.mode_set(mode=initial_mode)
        
        return {'FINISHED'}

# --- SMARTY EDGE FLOW (LOGIC FIX) ---
class OMONIX_OT_SmartyEdgeFlow(bpy.types.Operator):
    bl_idname = "omonix.shaper_edge_flow"
    bl_label = "Smarty Edge Flow"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply Edge Flow (addon) or fall back to standard Mesh Smooth."
    
    def execute(self, context):
        if context.mode != 'EDIT_MESH':
             self.report({'WARNING'}, "Please enter Mesh Edit Mode.")
             return {'CANCELLED'}
             
        if hasattr(bpy.ops.mesh, 'set_edge_flow'):
            # Option 1: Edge Flow Addon is active
            bpy.ops.mesh.set_edge_flow('INVOKE_DEFAULT')
            self.report({'INFO'}, "Smarty Edge Flow (Addon) called.")
            
        else:
            # Option 2: Fallback to built-in Blender Edge Smooth
            try:
                # Using bpy.ops.mesh.smooth() as fallback
                bpy.ops.mesh.smooth()
                self.report({'INFO'}, "Smarty Edge Flow: Mesh Smooth fallback called.")
            except RuntimeError as e:
                self.report({'ERROR'}, f"Failed to run Mesh Smooth: {e.args[0]}")
                
        return {'FINISHED'}
    
# --- NEW OPERATOR: UV UNWRAP PROXY ---
class OMONIX_OT_UVUnwrapProxy(bpy.types.Operator):
    bl_idname = "omonix.shaper_uv_unwrap"
    bl_label = "UV Unwrap"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Perform Smart UV Project or Standard Unwrap."
    
    uv_type: bpy.props.EnumProperty(
        items=[('SMART', "Smart UV Project (Fast)", "UV Project based on angles."), ('UNWRAP', "Unwrap (Adjustable)", "Standard UV Unwrap with F9 settings."),],
        name="Unwrap Type",
        default='SMART'
    )
    
    @classmethod
    def poll(cls, context): 
        return context.active_object and context.active_object.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        if self.uv_type == 'SMART':
            bpy.ops.uv.smart_project('EXEC_DEFAULT')
            self.report({'INFO'}, "Smart UV Project completed.")
        elif self.uv_type == 'UNWRAP':
            bpy.ops.uv.unwrap('INVOKE_DEFAULT')
            self.report({'INFO'}, "Standard Unwrap executed (F9 settings available).")
        
        return {'FINISHED'}

# --- Duplicate Related Operators ---
class OMONIX_OT_CallDuplicateMenu(bpy.types.Operator):
    bl_idname = "omonix.duplicate_menu"; bl_label = "Smart Duplicate"; bl_options = {'INTERNAL'} # Label changed
    bl_description = "Smart Duplicate (Object/Separate) and place at mouse pointer."
    def execute(self, context): bpy.ops.wm.call_menu(name="OMONIX_MT_duplicate_menu"); return {'FINISHED'}
class OMONIX_OT_Duplicate(bpy.types.Operator):
    bl_idname = "omonix.duplicate_objects"; bl_label = "Duplicate Objects (Show Params)"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Duplicate objects and show the parameter popup (F9)."
    @classmethod
    def poll(cls, context): return context.active_object is not None
    def execute(self, context): bpy.ops.object.duplicate_move('INVOKE_DEFAULT'); self.report({'INFO'}, "Object duplicated with parameter pop-up."); return {'FINISHED'}


# --- Shaper Dropdown Menu (Smooth Tools Removed from here) ---
class OMONIX_MT_ShaperMenu(bpy.types.Menu):
    bl_idname = "OMONIX_MT_shaper_menu"; bl_label = "Shaper Tools"
    def draw(self, context):
        layout = self.layout
        
        layout.operator(OMONIX_OT_FastRelax.bl_idname, icon='MOD_SMOOTH')
        layout.operator(OMONIX_OT_SmartyEdgeFlow.bl_idname, icon='IPO_EASE_IN_OUT')
        
        layout.separator()
        
        op_smart = layout.operator(OMONIX_OT_UVUnwrapProxy.bl_idname, text="Smart UV (Fast)", icon='UV_DATA')
        op_smart.uv_type = 'SMART'
        
        op_unwrap = layout.operator(OMONIX_OT_UVUnwrapProxy.bl_idname, text="Unwrap (Adjust)", icon='UV_SINUS')
        op_unwrap.uv_type = 'UNWRAP'
        
        layout.separator()
        layout.operator("omonix.apply_all_modifiers", text="Apply All Modifiers", icon='FILE_TICK') 

# --- Shaper Menu Caller Operator ---
class OMONIX_OT_CallShaperMenu(bpy.types.Operator):
    bl_idname = "omonix.shaper_menu"; bl_label = "Call Shaper Menu"; bl_options = {'INTERNAL'}
    def execute(self, context): bpy.ops.wm.call_menu(name=OMONIX_MT_ShaperMenu.bl_idname); return {'FINISHED'}

# --- List of Classes for Automatic Registration ---
classes_to_register = (
    OMONIX_OT_SmoothMesh, OMONIX_OT_SmoothCurve, OMONIX_OT_FastRelax, OMONIX_OT_SmartyEdgeFlow, OMONIX_OT_UVUnwrapProxy, 
    OMONIX_MT_ShaperMenu, OMONIX_OT_CallShaperMenu, OMONIX_OT_Duplicate, 
)