# File: operator.py (STABLE 2.1.0 - Context-Aware Lattice)
import bpy
import bmesh
import mathutils
from math import inf
from bpy.types import Operator
from bpy.props import EnumProperty
from bpy_extras.view3d_utils import region_2d_to_vector_3d, region_2d_to_location_3d

# --- HELPER FUNCTION: Get Bounding Box of All Selected Objects ---
def get_selection_bbox(selected_objects):
    """
    Calculates the total world-space bounding box for a list of objects.
    Returns (dimensions, center)
    """
    min_vec = mathutils.Vector((inf, inf, inf))
    max_vec = mathutils.Vector((-inf, -inf, -inf))
    
    has_valid_objects = False
    
    for obj in selected_objects:
        # Use obj.bound_box (local space) and convert to world space
        if hasattr(obj, "bound_box"):
            has_valid_objects = True
            for local_corner in obj.bound_box:
                world_corner = obj.matrix_world @ mathutils.Vector(local_corner)
                min_vec.x = min(min_vec.x, world_corner.x)
                min_vec.y = min(min_vec.y, world_corner.y)
                min_vec.z = min(min_vec.z, world_corner.z)
                max_vec.x = max(max_vec.x, world_corner.x)
                max_vec.y = max(max_vec.y, world_corner.y)
                max_vec.z = max(max_vec.z, world_corner.z)

    if not has_valid_objects:
        return None, None # No geometry found

    dimensions = max_vec - min_vec
    center = min_vec + (dimensions / 2.0)
    return dimensions, center
# --- END HELPER FUNCTION ---


class OMONIX_OT_AddPrimitives(Operator):
    """Creates a primitive at the mouse pointer location (if possible), then enters interactive placement mode."""
    bl_idname = "omonix.add_primitives"
    bl_label = "Add Primitive Omonix"
    bl_options = {"REGISTER", "UNDO"}

    primitive: EnumProperty(
        items=(
            ('cube', "Cube", ""), ('cylinder', "Cylinder", ""), ('plane', "Plane", ""),
            ('sphere', "UV Sphere", ""), ('icosphere', "Ico Sphere", ""), ('cone', "Cone", ""),
            ('mesh_circle', "Circle", ""), ('torus', "Torus", ""), ('vertex', "Vertex", ""),
            ('lattice', "Lattice", ""), ('armature', "Armature", ""), ('empty_axe', "Empty Axes", ""),
            ('bezier', "Bezier", ""), ('circle', "Bezier Circle", ""), ('curve_line', "Curve Line", ""),
            ('text', "Text", ""), ('point', "Point Light", ""), ('camera', "Camera", ""),
            ('grid', "Grid", ""),
        ),
        default='cube'
    )
    
    # Map (digunakan oleh create_from_map)
    PRIMITIVE_MAP = {
        'cube': ('mesh', 'primitive_cube_add', {}),
        'cylinder': ('mesh', 'primitive_cylinder_add', {'vertices': 16}),
        'plane': ('mesh', 'primitive_plane_add', {}), 
        'sphere': ('mesh', 'primitive_uv_sphere_add', {'segments': 24, 'ring_count': 12}),
        'icosphere': ('mesh', 'primitive_ico_sphere_add', {'subdivisions': 2}),
        'cone': ('mesh', 'primitive_cone_add', {'vertices': 16}),
        'mesh_circle': ('mesh', 'primitive_circle_add', {'vertices': 16}),
        'torus': ('mesh', 'primitive_torus_add', {}),
        'empty_axe': ('object', 'empty_add', {'type': 'PLAIN_AXES'}),
        'bezier': ('curve', 'primitive_bezier_curve_add', {}),
        'circle': ('curve', 'primitive_bezier_circle_add', {}),
        'curve_line': ('curve', 'primitive_bezier_curve_add', {}),
        'text': ('object', 'text_add', {}),
        'point': ('object', 'light_add', {'type': 'POINT'}),
        'camera': ('object', 'camera_add', {}),
        'armature': ('object', 'armature_add', {}),
        'lattice': ('object', 'add', {'type': 'LATTICE'}), # v2.0.8 API Fix
        'grid': ('mesh', 'primitive_grid_add', {}),
    }

    def invoke(self, context, event):
        # Ensure Object Mode
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # --- 1. Get Mouse Location via Ray-Cast ---
        creation_loc = context.scene.cursor.location
        
        region = context.region
        rv3d = context.region_data
        if region and rv3d:
            mouse_pos = (event.mouse_region_x, event.mouse_region_y)
            vec = region_2d_to_vector_3d(region, rv3d, mouse_pos)
            ray_origin = region_2d_to_location_3d(region, rv3d, mouse_pos, vec)
            
            result, location, normal, index, object, matrix = context.scene.ray_cast(context.view_layer.depsgraph, ray_origin, vec)
            if result:
                creation_loc = location # Update location if ray-cast hits something

        # --- 2. Handle Primitive Creation ---
        
        # Special case for 'vertex'
        if self.primitive == 'vertex':
            bpy.ops.mesh.primitive_plane_add(enter_editmode=True, align='WORLD', location=creation_loc)
            bpy.ops.mesh.merge(type='CENTER')
            bpy.ops.object.mode_set(mode='OBJECT')

        # --- PERUBAHAN DI SINI: Special case for 'lattice' ---
        elif self.primitive == 'lattice':
            selected_objects = context.selected_objects
            
            if not selected_objects:
                # --- Condition 1: No selection ---
                # Create default lattice at mouse pointer
                bpy.ops.object.add(type='LATTICE', align='WORLD', location=creation_loc)
                new_lattice_obj = context.active_object
                # Set default subdivisions (1 subdivision = 2 points)
                if new_lattice_obj and new_lattice_obj.type == 'LATTICE':
                    new_lattice_obj.data.points_u = 2
                    new_lattice_obj.data.points_v = 2
                    new_lattice_obj.data.points_w = 2
            else:
                # --- Condition 2: Objects are selected ---
                dimensions, center = get_selection_bbox(selected_objects)
                
                if dimensions is None:
                    self.report({'WARNING'}, "Selected objects have no geometry to bound.")
                    return {'CANCELLED'}

                # Create lattice at the center of the selection's bounding box
                bpy.ops.object.add(type='LATTICE', align='WORLD', location=center)
                new_lattice_obj = context.active_object
                
                if new_lattice_obj and new_lattice_obj.type == 'LATTICE':
                    # Set dimensions to match selection
                    new_lattice_obj.dimensions = dimensions
                    
                    # Set default subdivisions (1 subdivision = 2 points)
                    new_lattice_obj.data.points_u = 2
                    new_lattice_obj.data.points_v = 2
                    new_lattice_obj.data.points_w = 2
                    
                    # Deselect others and select the new lattice
                    for obj in selected_objects:
                        obj.select_set(False)
                    new_lattice_obj.select_set(True)
        # --- AKHIR PERUBAHAN ---

        else:
            # Fallback for all other primitives
            self.create_from_map(context, creation_loc)
        
        # --- 3. Try to call Place Helper (if available) ---
        try:
            bpy.ops.ph.move_object('INVOKE_DEFAULT')
        except (AttributeError, RuntimeError):
            # Fallback: Call built-in 'Move'
            bpy.ops.transform.translate('INVOKE_DEFAULT')
            
        return {'FINISHED'}


    def create_from_map(self, context, location):
        op_data = self.PRIMITIVE_MAP.get(self.primitive)
        if not op_data:
            self.report({'ERROR'}, f"Primitive '{self.primitive}' not found in map.")
            return

        op_module_str, op_name_str, default_kwargs = op_data
        
        try:
            op_module = getattr(bpy.ops, op_module_str)
            op_func = getattr(op_module, op_name_str)
            kwargs = default_kwargs.copy()
            
            if op_module_str in ['mesh', 'object', 'curve']:
                kwargs['align'] = 'WORLD'
            
            kwargs['location'] = location
            
            op_func(**kwargs)
        except (AttributeError, TypeError) as e:
            self.report({'WARNING'}, f"Could not create '{self.primitive}'. Error: {e}")

# --- Registration ---
classes_to_register = (
    OMONIX_OT_AddPrimitives,
)