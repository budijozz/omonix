# File: _uiorigin.py (Fixes and Translation)

import bpy
from mathutils import Vector

# --- Helper Functions for Origin (Logic remains the same) ---
def get_world_bbox_corners(obj):
    return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]

def move_origin_to_side(obj, axis, value_index):
    original_cursor_location = bpy.context.scene.cursor.location.copy()
    try:
        bbox_corners_world = get_world_bbox_corners(obj)
        coords_list = [[v[i] for v in bbox_corners_world] for i in range(3)]
        min_max_list = [(min(coords), max(coords)) for coords in coords_list]
        target_coords = [0.0, 0.0, 0.0]
        for i in range(3):
            target_coords[i] = min_max_list[i][value_index] if i == axis else (min_max_list[i][0] + min_max_list[i][1]) / 2
        bpy.context.scene.cursor.location = Vector(target_coords)
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
    finally:
        bpy.context.scene.cursor.location = original_cursor_location

def move_origin_to_center(obj):
    original_cursor_location = bpy.context.scene.cursor.location.copy()
    try:
        center = sum(get_world_bbox_corners(obj), Vector()) / 8
        bpy.context.scene.cursor.location = center
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
    finally:
        bpy.context.scene.cursor.location = original_cursor_location

# --- Operators for each Origin action (Labels translated) ---
class OMONIX_OT_OriginTop(bpy.types.Operator):
    bl_idname = "omonix.origin_top"; bl_label = "Top"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the top (Z+ boundary)."
    def execute(self, context): move_origin_to_side(context.object, 2, 1); return {'FINISHED'}
class OMONIX_OT_OriginBottom(bpy.types.Operator):
    bl_idname = "omonix.origin_bottom"; bl_label = "Bottom"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the bottom (Z- boundary)."
    def execute(self, context): move_origin_to_side(context.object, 2, 0); return {'FINISHED'}
class OMONIX_OT_OriginRight(bpy.types.Operator):
    bl_idname = "omonix.origin_right"; bl_label = "Right"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the right (X+ boundary)."
    def execute(self, context): move_origin_to_side(context.object, 0, 1); return {'FINISHED'}
class OMONIX_OT_OriginLeft(bpy.types.Operator):
    bl_idname = "omonix.origin_left"; bl_label = "Left"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the left (X- boundary)."
    def execute(self, context): move_origin_to_side(context.object, 0, 0); return {'FINISHED'}
class OMONIX_OT_OriginFront(bpy.types.Operator):
    bl_idname = "omonix.origin_front"; bl_label = "Front"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the front (Y+ boundary)."
    def execute(self, context): move_origin_to_side(context.object, 1, 1); return {'FINISHED'}
class OMONIX_OT_OriginBack(bpy.types.Operator):
    bl_idname = "omonix.origin_back"; bl_label = "Back"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the back (Y- boundary)."
    def execute(self, context): move_origin_to_side(context.object, 1, 0); return {'FINISHED'}
class OMONIX_OT_OriginCenter(bpy.types.Operator):
    bl_idname = "omonix.origin_center"; bl_label = "Center"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the bounding box center."
    def execute(self, context): move_origin_to_center(context.object); return {'FINISHED'}
class OMONIX_OT_OriginToCursor(bpy.types.Operator):
    bl_idname = "omonix.origin_to_cursor"; bl_label = "Cursor"; bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set Origin to the 3D Cursor location."
    def execute(self, context): bpy.ops.object.origin_set(type='ORIGIN_CURSOR'); return {'FINISHED'}

# --- Origin Pop-up Operator (New Grid Layout) ---
class OMONIX_OT_OriginMenu(bpy.types.Operator):
    """Displays a pop-up to set the object origin in an icon grid format."""
    bl_idname = "omonix.origin_menu"
    bl_label = "Set Origin"
    bl_description = "Full menu for setting the object origin."

    def invoke(self, context, event):
        # Width adjusted for the 4-icon grid layout
        return context.window_manager.invoke_popup(self, width=180)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        # Row 1: Top, Right, Front, Center
        row1 = col.row(align=True)
        row1.operator("omonix.origin_top", text="", icon='TRIA_UP')
        row1.operator("omonix.origin_right", text="", icon='TRIA_RIGHT')
        row1.operator("omonix.origin_front", text="", icon='TRIA_RIGHT_BAR')
        row1.operator("omonix.origin_center", text="", icon='OBJECT_DATAMODE')

        # Row 2: Bottom, Left, Back, Cursor
        row2 = col.row(align=True)
        row2.operator("omonix.origin_bottom", text="", icon='TRIA_DOWN')
        row2.operator("omonix.origin_left", text="", icon='TRIA_LEFT')
        row2.operator("omonix.origin_back", text="", icon='TRIA_LEFT_BAR')
        row2.operator("omonix.origin_to_cursor", text="", icon='CURSOR')

    def execute(self, context):
        return {'FINISHED'}

# --- List of Classes for Registration ---
classes_to_register = (
    OMONIX_OT_OriginTop, OMONIX_OT_OriginBottom, OMONIX_OT_OriginRight,
    OMONIX_OT_OriginLeft, OMONIX_OT_OriginFront, OMONIX_OT_OriginBack,
    OMONIX_OT_OriginCenter, OMONIX_OT_OriginToCursor, OMONIX_OT_OriginMenu,
)