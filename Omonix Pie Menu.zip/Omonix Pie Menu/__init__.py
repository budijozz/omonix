# -*- coding: utf-8 -*-
# --------------------------------------------------------------------------
# File: __init__.py (STABLE VERSION 2.1.0 - Context-Aware Lattice)
# --------------------------------------------------------------------------

bl_info = {
    "name": "Omonix Pie Menu", 
    "author": "Semangat Pagi Studio",
    "version": (2, 1, 0), # Version 2.1.0 (Lattice Feature)
    "blender": (4, 3, 0),
    "location": "3D View > Alt+RMB",
    "description": "Rapid pie menu with smart origin, context-aware edit mode, and advanced object tools.",
    "category": "Object",
}

import bpy
import os 
import importlib
import sys

# ======================================================================
# == CONFIGURATION CENTER ==
# ======================================================================

ADDON_DIR = os.path.dirname(os.path.realpath(__file__))
SCRIPT_PATHS = {
    "kocoxalus": os.path.join(ADDON_DIR, "shaper_mesh", "kocoxalus.py"),
    "smooth_draw": os.path.join(ADDON_DIR, "shaper_curve", "smooth_draw.py"),
}

# External addon status dictionary
ADDON_STATUS = {"MatColeX": False, "QRemeshify": False, "EdgeFlow": False, "PlaceHelper": False}

def check_external_addons():
    """Checks if external addons are active and updates their status."""
    ADDON_STATUS["MatColeX-Pro"] = "matcolex-pro" in bpy.context.preferences.addons
    ADDON_STATUS["QRemeshify"] = hasattr(bpy.ops, "qremeshify")
    ADDON_STATUS["EdgeFlow"] = hasattr(bpy.ops.mesh, "set_edge_flow")
    ADDON_STATUS["PlaceHelper"] = hasattr(bpy.ops, "ph") and hasattr(bpy.ops.ph, "move_object")
    print("Omonix: External addon status checked:", ADDON_STATUS)

# ======================================================================
# == BLENDER ADDON PREFERENCES ==
# ======================================================================

class OMONIX_PT_AddonPreferences(bpy.types.AddonPreferences):
    """Adds a preferences panel to check for optional external addons."""
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="External Addon Status", icon='INFO')
        box.label(text="Ensure these addons are enabled for full functionality:", icon='QUESTION')
        
        row = box.row(align=True)
        col = row.column(align=True)
        col.label(text="Addon Name", icon='ADD')
        col.label(text="MatColeX-Pro")
        col.label(text="QRemeshify")
        col.label(text="Edge Flow")
        col.label(text="Place Helper")

        col = row.column(align=True)
        col.label(text="Status", icon='CHECKMARK')
        
        is_pro_active = ADDON_STATUS.get("MatColeX-Pro", False)
        col.label(text="Active" if is_pro_active else "Inactive", 
                  icon='CHECKMARK' if is_pro_active else 'CANCEL')
        col.label(text="Active" if ADDON_STATUS["QRemeshify"] else "Inactive", 
                  icon='CHECKMARK' if ADDON_STATUS["QRemeshify"] else 'CANCEL')
        col.label(text="Active" if ADDON_STATUS["EdgeFlow"] else "Inactive", 
                  icon='CHECKMARK' if ADDON_STATUS["EdgeFlow"] else 'CANCEL')
        col.label(text="Active" if ADDON_STATUS["PlaceHelper"] else "Inactive", 
                  icon='CHECKMARK' if ADDON_STATUS["PlaceHelper"] else 'CANCEL')

# ======================================================================
# == CUSTOM ICON HANDLING (PLACEHOLDER) ==
# ======================================================================

def load_custom_icons(): pass
def clear_custom_icons(): pass


# ======================================================================
# == IMPORT ALL MODULES ==
# ======================================================================

from . import (
    operator, _uishaper, _uiorigin, _uisnap, _uiduplicate, _uimirror, 
    _uiempty, _uiobject, _uilink, _uieditmode, 
)

# Memastikan kita mengimpor file operator yang benar
from .operator import OMONIX_OT_AddPrimitives 
# Memastikan kita mengimpor file origin yang benar
from ._uiorigin import (
    OMONIX_OT_OriginTop, OMONIX_OT_OriginBottom, OMONIX_OT_OriginRight, 
    OMONIX_OT_OriginLeft, OMONIX_OT_OriginFront, OMONIX_OT_OriginBack,
    OMONIX_OT_OriginCenter, OMONIX_OT_OriginToCursor
)
# Memastikan kita mengimpor file editmode yang benar
from ._uieditmode import (
    OMONIX_OT_CallSelectLinkedMenu, OMONIX_OT_CallEdgeToolsMenu,
    OMONIX_OT_CallLoopToolsMenu, OMONIX_OT_InvokeSubdivide,
    OMONIX_OT_VertexBevel, OMONIX_OT_EdgeBevel,
    OMONIX_OT_EdgeCrease, OMONIX_OT_MergeByDistance,
)
# Memastikan kita mengimpor file shaper yang benar
from ._uishaper import (
    OMONIX_OT_FastRelax, OMONIX_OT_SmartyEdgeFlow, OMONIX_OT_UVUnwrapProxy
)


# ======================================================================
# == MAIN PIE MENU (SMART MODE LOGIC) ==
# ======================================================================

class OMONIX_MT_MainPie(bpy.types.Menu):
    bl_idname = "OMONIX_MT_main_pie"
    bl_label = "Omonix Pie"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        
        mode = context.mode
        is_object_mode = (mode == 'OBJECT')
        is_mesh_edit_mode = (mode == 'EDIT_MESH')
        is_curve_edit_mode = (mode == 'EDIT_CURVE')
        is_other_edit_mode = (mode in {'EDIT_SURFACE', 'EDIT_LATTICE', 'EDIT_ARMATURE'})
        
        
        if is_object_mode:
            # =============================
            # A. OBJECT MODE (Final Layout)
            # =============================
            
            # 1. DUPLICATE (Top-Left)
            pie.operator("omonix.duplicate_menu", text="Smart Duplicate", icon='DUPLICATE')
            
            # 2. ORIGIN (Top-Right)
            origin_col = pie.column()
            row1 = origin_col.row(align=True)
            row1.operator(OMONIX_OT_OriginTop.bl_idname, text="", icon='TRIA_UP')
            row1.operator(OMONIX_OT_OriginBottom.bl_idname, text="", icon='TRIA_DOWN')
            row1.operator(OMONIX_OT_OriginCenter.bl_idname, text="", icon='OBJECT_DATAMODE')
            row1.operator(OMONIX_OT_OriginToCursor.bl_idname, text="", icon='CURSOR')
            row2 = origin_col.row(align=True)
            row2.operator(OMONIX_OT_OriginRight.bl_idname, text="", icon='TRIA_RIGHT')
            row2.operator(OMONIX_OT_OriginLeft.bl_idname, text="", icon='TRIA_LEFT')
            row2.operator(OMONIX_OT_OriginFront.bl_idname, text="", icon='TRIA_RIGHT_BAR')
            row2.operator(OMONIX_OT_OriginBack.bl_idname, text="", icon='TRIA_LEFT_BAR')

            # 3. ADD OBJECT (Bottom-Left) - Balanced 6/6/6 Layout
            object_col = pie.column()
            box = object_col.box()
            col = box.column(align=True)
            op_id = OMONIX_OT_AddPrimitives.bl_idname
            
            # Row 1 (Mesh Primitives) - 6 items
            row1 = col.row(align=True)
            for icon, prim in [
                ('MESH_CUBE', 'cube'), ('MESH_CYLINDER', 'cylinder'), ('MESH_PLANE', 'plane'), 
                ('MESH_UVSPHERE', 'sphere'), ('MESH_ICOSPHERE', 'icosphere'), ('MESH_CONE', 'cone')
            ]:
                op = row1.operator(op_id, text="", icon=icon); op.primitive = prim
                
            # Row 2 (Other Objects/Utilities) - 6 items
            row2 = col.row(align=True)
            for icon, prim in [
                ('MESH_CIRCLE', 'mesh_circle'), ('MESH_TORUS', 'torus'), ('MESH_GRID', 'grid'), 
                ('FILE_FONT', 'text'), ('OUTLINER_OB_ARMATURE', 'armature'), ('OUTLINER_OB_EMPTY', 'empty_axe')
            ]:
                op = row2.operator(op_id, text="", icon=icon); op.primitive = prim
                
            # Row 3 (Curves/Lattice/Lights/Camera) - 6 items
            row3 = col.row(align=True)
            for icon, prim in [
                ('OUTLINER_OB_LATTICE', 'lattice'), 
                ('CURVE_BEZCURVE', 'bezier'), 
                ('CURVE_NCIRCLE', 'circle'), 
                ('CURVE_PATH', 'curve_line'), 
                ('LIGHT', 'point'), 
                ('CAMERA_DATA', 'camera')
            ]:
                op = row3.operator(op_id, text="", icon=icon); op.primitive = prim

            # 4. QUICK TOOLS (Left)
            quick_tools_col = pie.column()
            quick_tools_col.operator("omonix.apply_all_modifiers", text="Apply Modifiers", icon='FILE_TICK')
            if ADDON_STATUS["QRemeshify"]:
                quick_tools_col.operator("omonix.shaper_qremesh", text="Quad Remesh", icon='MOD_REMESH')
            else:
                quick_tools_col.label(text="Quad Remesh (Addon Req.)", icon='CANCEL') 

            # 5. LINK TOOLS (Right)
            link_col = pie.column(align=True)
            op_mods = link_col.operator("object.make_links_data", text="Copy Modifiers", icon='MODIFIER')
            op_mods.type = 'MODIFIERS'
            op_others = link_col.operator("wm.call_menu", text="Others", icon='DOWNARROW_HLT')
            op_others.name = "OMONIX_MT_link_others_menu"

            # 6. APPLY TOOLS (Bottom-Right)
            apply_col = pie.column(align=True)
            apply_col.operator("omonix.apply_all_transforms", text="Apply All Transforms", icon='CONSTRAINT_BONE')
            op = apply_col.operator("wm.call_menu", text="Others", icon='DOWNARROW_HLT')
            op.name = "OMONIX_MT_apply_tools_menu"

            # 7. MIRROR & SNAP (Top)
            mirror_snap_col = pie.column()
            mirror_snap_col.operator("omonix.mirror_menu", text="Mirror Tools", icon='MOD_MIRROR')
            snap_label = "Snap/Move to Pointer" if ADDON_STATUS["PlaceHelper"] else "Snap Tool (Place Helper Req.)"
            snap_icon = 'SNAP_ON' if ADDON_STATUS["PlaceHelper"] else 'CANCEL'
            mirror_snap_col.operator("omonix.call_place_tool", text=snap_label, icon=snap_icon)

            # 8. MATCOLEX & QUICK FX (Bottom)
            matcolex_col = pie.column(align=True) 
            matcolex_col.operator("omonix.call_material_list_menu", text="MatColeX", icon='MATERIAL')
            matcolex_col.operator("omonix.call_smoothy_menu", text="Quick FX", icon='SMOOTHCURVE')


        elif is_mesh_edit_mode:
            # ========================================================
            # B. MESH EDIT MODE (Context-Aware Stable Logic)
            # ========================================================
            
            # Get active selection mode
            select_mode = context.tool_settings.mesh_select_mode
            is_vert_mode = select_mode[0]
            is_edge_mode = select_mode[1]
            is_face_mode = select_mode[2]
            
            # --- 1. SHAPING TOOLS (Top-Left) ---
            shaping_col = pie.column(align=True)
            shaping_col.operator(OMONIX_OT_FastRelax.bl_idname, text="Relax Verts", icon='MOD_SMOOTH')
            if ADDON_STATUS["EdgeFlow"]:
                shaping_col.operator(OMONIX_OT_SmartyEdgeFlow.bl_idname, text="Smarty Edge Flow", icon='IPO_EASE_IN_OUT')
            else:
                shaping_col.operator(OMONIX_OT_SmartyEdgeFlow.bl_idname, text="Mesh Smooth (Edge Flow Req.)", icon='CANCEL')
            
            # --- 2. UV TOOLS (Top-Right) ---
            uv_col = pie.column(align=True)
            op_smart = uv_col.operator(OMONIX_OT_UVUnwrapProxy.bl_idname, text="Smart UV", icon='UV_DATA')
            op_smart.uv_type = 'SMART'
            uv_col.operator("uv.project_from_view", text="Project From View", icon='VIEW_ORTHO')
            
            # --- 3. SELECTION TOOLS (Bottom-Left) ---
            select_col = pie.column(align=True) 
            select_col.operator(OMONIX_OT_CallSelectLinkedMenu.bl_idname, text="Select Linked", icon='LINKED')
            if is_face_mode:
                op_perim = select_col.operator("mesh.select_similar", text="Perimeter", icon='SELECT_SET') 
                op_perim.type = 'FACE_PERIMETER'
            elif is_edge_mode:
                select_col.operator("mesh.select_boundaries", text="Select Boundary", icon='SELECT_SET') 
            elif is_vert_mode:
                select_col.operator("mesh.select_loose", text="Select Loose", icon='SELECT_SET') 
            
            # --- 4. EDGE TOOLS (Left) ---
            pie.operator(OMONIX_OT_CallEdgeToolsMenu.bl_idname, text="Edge Tools", icon='EDGESEL')
            
            # --- 5. CONTEXTUAL: VERTEX / EDGE / FACE TOOLS (Right) ---
            context_col = pie.column(align=True)
            if is_face_mode:
                context_col.operator("mesh.poke", text="Poke Face", icon='TRIA_DOWN')
                context_col.operator("mesh.triangulate", text="Triangulate", icon='MESH_GRID')
                context_col.operator("mesh.tris_convert_to_quads", text="Tri to Quads", icon='MESH_PLANE')
            elif is_edge_mode:
                context_col.operator(OMONIX_OT_EdgeBevel.bl_idname, text="Bevel Edges", icon='MOD_BEVEL')
                context_col.operator(OMONIX_OT_EdgeCrease.bl_idname, text="Edge Crease", icon='SHARPCURVE')
            elif is_vert_mode:
                context_col.operator(OMONIX_OT_VertexBevel.bl_idname, text="Bevel Verts", icon='MOD_BEVEL')
                context_col.operator("mesh.vert_connect_path", text="Connect Path", icon='IPO_LINEAR')
            
            # --- 6. SPLIT TOOLS (Bottom-Right) ---
            split_col = pie.column(align=True)
            split_col.operator("mesh.split", text="Split", icon='SPLIT_HORIZONTAL') 
            split_col.operator("mesh.separate", text="Separate", icon='GROUP_VERTEX').type = 'SELECTED'
            
            # --- 7. LOOP TOOLS (Top) ---
            pie.operator(OMONIX_OT_CallLoopToolsMenu.bl_idname, text="Loop Tools", icon='MOD_SUBSURF') 
            
            # --- 8. CONTEXTUAL: SUBDIVIDE & SECOND TOOL (Bottom) ---
            extrude_col = pie.column(align=True)
            extrude_col.operator(OMONIX_OT_InvokeSubdivide.bl_idname, text="Subdivide", icon='MOD_SUBSURF')
            if is_face_mode:
                extrude_col.operator("mesh.select_checker_deselect", text="Checker", icon='MOD_MASK') 
            elif is_edge_mode:
                extrude_col.operator("mesh.bridge_edge_loops", text="Bridge Loops", icon='MOD_ARRAY')
            elif is_vert_mode:
                extrude_col.operator(OMONIX_OT_MergeByDistance.bl_idname, text="Merge By Distance", icon='AUTOMERGE_ON')

        elif is_curve_edit_mode:
            pie.label(text="Curve Edit Mode", icon='CURVE_DATA')
        elif is_other_edit_mode:
            pie.label(text=f"Edit Mode: {mode}", icon='CANCEL')
        else:
            pie.label(text="Mode Not Supported", icon='CANCEL')

# ======================================================================
# == REGISTRATION ==
# ======================================================================

modules_to_register = [
    operator, _uishaper, _uiorigin, _uisnap, _uiduplicate, _uimirror, 
    _uiempty, _uiobject, _uilink, _uieditmode,
]

classes = [OMONIX_MT_MainPie, OMONIX_PT_AddonPreferences] 

for module in modules_to_register:
    if hasattr(module, "classes_to_register"):
        classes.extend(module.classes_to_register)

addon_keymaps = []

def register():
    # Dynamic module import
    for module in modules_to_register:
        module_name = f".{module.__name__.split('.')[-1]}"
        try:
            importlib.import_module(module_name, __package__) 
        except ImportError as e:
             print(f"Omonix Warning: Failed to load module {module_name}: {e}")
    
    load_custom_icons() 
    check_external_addons()

    for cls in classes:
        bpy.utils.register_class(cls)

    # Add Keymap
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        kmi = km.keymap_items.new("wm.call_menu_pie", "RIGHTMOUSE", "PRESS", alt=True)
        kmi.properties.name = OMONIX_MT_MainPie.bl_idname
        addon_keymaps.append((km, kmi))

def unregister():
    # Remove Keymap
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    clear_custom_icons() 
    
    # Unregister classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        
    # Clear modules
    for module in modules_to_register:
        module_name = module.__name__.split('.')[-1]
        full_module_name = f"{__package__}.{module_name}"
        if full_module_name in sys.modules:
            del sys.modules[full_module_name]

if __name__ == "__main__":
    register()