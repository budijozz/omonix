# File: _uiduplicate.py (FIXED: Smart Duplicate to Mouse Pointer and Translated)
import bpy
# MAIN IMPORT FOR RAY CAST
from bpy_extras.view3d_utils import region_2d_to_vector_3d, region_2d_to_location_3d

# --- Helper Operator: Solidify (Translated) ---
class OMONIX_OT_ApplySolidifyWithPopup(bpy.types.Operator):
    bl_idname = "omonix.apply_solidify_with_popup"
    bl_label = "Add Solidify Modifier"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Add Solidify modifier with thickness and offset options."
    thickness: bpy.props.FloatProperty(name="Thickness", default=0.02, unit='LENGTH')
    offset: bpy.props.FloatProperty(name="Offset", default=-1.0, min=-1.0, max=1.0)
    use_even_offset: bpy.props.BoolProperty(name="Even Thickness", default=True)
    
    @classmethod
    def poll(cls, context): return context.active_object is not None
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context):
        layout = self.layout; layout.use_property_split = True
        layout.prop(self, "thickness"); layout.prop(self, "offset"); layout.prop(self, "use_even_offset")
    def execute(self, context):
        mod = context.active_object.modifiers.new(name="OmonixSolidify", type='SOLIDIFY')
        mod.thickness = self.thickness; mod.offset = self.offset; mod.use_even_offset = self.use_even_offset
        self.report({'INFO'}, "Solidify modifier added.")
        return {'FINISHED'}

# --- Main Operator: Smart Duplicate (Translated) ---
class OMONIX_OT_SmartDuplicate(bpy.types.Operator):
    """Duplicates the object and instantly runs the move operator (Place Helper or Fallback) at the mouse location."""
    bl_idname = "omonix.smart_duplicate"
    bl_label = "Smart Duplicate"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Duplicate/Separate and start interactive move/snap at mouse pointer location."

    # Helper function to call move tool
    def call_move_tool(self, context):
        try:
            # Check for Place Helper and call it
            bpy.ops.ph.move_object('INVOKE_DEFAULT')
            self.report({'INFO'}, "Place Helper called after duplication.")
        except (AttributeError, RuntimeError):
            self.report({'INFO'}, "Place Helper not found. Switching to default Move tool.")
            bpy.ops.transform.translate('INVOKE_DEFAULT')
            
    def invoke(self, context, event): # Using invoke to access event
        active_obj = context.active_object
        if not active_obj: return {'CANCELLED'}
        
        mode = active_obj.mode
        
        # --- 1. RAY CAST LOGIC ---
        creation_loc = context.scene.cursor.location.copy()
        
        region = context.region
        rv3d = context.region_data
        
        if region and rv3d:
            mouse_pos = (event.mouse_region_x, event.mouse_region_y)
            vec = region_2d_to_vector_3d(region, rv3d, mouse_pos)
            ray_origin = region_2d_to_location_3d(region, rv3d, mouse_pos, vec)
            
            # Ray-cast against all objects in the scene
            result, location, normal, index, obj, matrix = context.scene.ray_cast(context.view_layer.depsgraph, ray_origin, vec)
            if result:
                creation_loc = location
        
        # --- 2. DUPLICATE / SEPARATE ---
        
        if mode == 'OBJECT':
            bpy.ops.object.duplicate(linked=False)
            new_obj = context.active_object
            
            # Move object to the ray-cast location before calling the move tool
            new_obj.location = creation_loc
            
            self.call_move_tool(context)
            
            return {'FINISHED'}

        elif mode == 'EDIT_MESH': # Changed from 'EDIT' to 'EDIT_MESH' for clarity and safety
            original_obj = context.active_object
            
            # Duplicate and Separate
            bpy.ops.mesh.duplicate_move()
            
            # NOTE: We can't immediately separate in the same operator execution without mode switch, 
            # and SmartSeparate handles the full Edit Mode workflow better.
            # For simplicity and to follow the original logic (DuplicateMove is usually followed by a move), 
            # we will only run duplicate_move here and let the user execute Separate later, 
            # OR we can replicate the SmartSeparate full workflow here.

            # Replicating the full Edit Mode workflow for a truly "Smart" duplicate
            
            # A. SEPARATE (Instead of just duplicate_move)
            try:
                # We assume the user has a selection in EDIT_MESH mode for 'Smart Duplicate'
                bpy.ops.mesh.separate(type='SELECTED')
            except RuntimeError:
                self.report({'WARNING'}, "No selected elements to separate. Running regular Duplicate instead.")
                bpy.ops.mesh.duplicate_move('INVOKE_DEFAULT')
                return {'CANCELLED'} # The regular duplicate will handle the rest
            
            # B. Switch to Object Mode
            bpy.ops.object.mode_set(mode='OBJECT')
            new_obj = next((obj for obj in context.selected_objects if obj != original_obj), None)
            
            if new_obj:
                original_obj.select_set(False)
                context.view_layer.objects.active = new_obj
                new_obj.select_set(True)
                
                # C. Move object to the ray-cast location
                new_obj.location = creation_loc
                
                # D. Call Move Tool
                self.call_move_tool(context)

                # E. Call Solidify Pop-up
                bpy.ops.omonix.apply_solidify_with_popup('INVOKE_DEFAULT')
                
            return {'FINISHED'}
        
        else:
             self.report({'WARNING'}, "Active mode not supported for Smart Duplicate.")
             return {'CANCELLED'}
    
    # execute only returns FINISHED because all logic is in invoke
    def execute(self, context): return {'FINISHED'}


# --- Caller Operator for Menu (Changed to call Smart Duplicate directly) ---
class OMONIX_OT_CallDuplicateMenu(bpy.types.Operator):
    bl_idname = "omonix.duplicate_menu"
    bl_label = "Smart Duplicate/Separate" # New Label
    bl_description = "Duplicate (Object Mode) or Separate (Edit Mode) and start move/snap at mouse location."
    def execute(self, context):
        # Calls the invoke of Smart Duplicate
        bpy.ops.omonix.smart_duplicate('INVOKE_DEFAULT') 
        return {'FINISHED'}

# --- List of Classes for Registration ---
classes_to_register = (
    OMONIX_OT_ApplySolidifyWithPopup,
    OMONIX_OT_SmartDuplicate,
    OMONIX_OT_CallDuplicateMenu,
)