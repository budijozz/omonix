# File: _uimirror.py (Final Fix and Translation)

import bpy

# --- Operator to Add Mirror Modifier (Translated) ---
class OMONIX_OT_AddMirrorModifier(bpy.types.Operator):
    bl_idname = "omonix.mirror_add_modifier"
    bl_label = "Add Mirror Modifier"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Add a non-destructive Mirror Modifier with optional Clipping."

    axis_x: bpy.props.BoolProperty(name="X", default=True)
    axis_y: bpy.props.BoolProperty(name="Y", default=False)
    axis_z: bpy.props.BoolProperty(name="Z", default=False)
    use_clip: bpy.props.BoolProperty(name="Clipping", default=True) # Name changed to Clipping
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        row = layout.row(heading="Mirror Axis")
        row.prop(self, "axis_x")
        row.prop(self, "axis_y")
        row.prop(self, "axis_z")
        layout.prop(self, "use_clip")

    def execute(self, context):
        for obj in context.selected_objects:
            mod = obj.modifiers.new(name="OmonixMirror", type='MIRROR')
            mod.use_axis[0] = self.axis_x
            mod.use_axis[1] = self.axis_y
            mod.use_axis[2] = self.axis_z
            mod.use_clip = self.use_clip
        self.report({'INFO'}, "Mirror Modifier added.")
        return {'FINISHED'}


# --- New Operator for Object Mirroring (Grid) (Translated) ---
class OMONIX_OT_MirrorObjectAxis(bpy.types.Operator):
    """Base operator to perform a mirror transform on a single axis."""
    bl_idname = "omonix.mirror_object_axis" 
    bl_label = "Mirror Object on Axis"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Performs a destructive mirror transform on the selected axis."
    
    axis: bpy.props.IntProperty(name="Axis")

    def execute(self, context):
        constraint_axis = [False, False, False]
        constraint_axis[self.axis] = True
        axis_name = ['X', 'Y', 'Z'][self.axis]
        bpy.ops.transform.mirror('EXEC_DEFAULT', constraint_axis=tuple(constraint_axis))
        self.report({'INFO'}, f"Object mirrored on {axis_name} axis.")
        return {'FINISHED'}

# --- Main Mirror Menu (New View) (Translated) ---
class OMONIX_OT_MirrorMenu(bpy.types.Operator):
    bl_idname = "omonix.mirror_menu"
    bl_label = "Mirror Tools"
    bl_description = "Pop-up menu for both non-destructive (Modifier) and destructive (Transform) mirroring."

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=200)

    def draw(self, context):
        layout = self.layout
        main_col = layout.column(align=True)

        main_col.label(text="Modifier (Non-Destructive):", icon='MODIFIER')
        main_col.operator(OMONIX_OT_AddMirrorModifier.bl_idname, text="Add Mirror Modifier", icon='MOD_MIRROR')
        
        main_col.separator()

        main_col.label(text="Object Transform (Destructive):", icon='DRIVER_TRANSFORM')
        row = main_col.row(align=True)
        
        op_x = row.operator(OMONIX_OT_MirrorObjectAxis.bl_idname, text="X Axis")
        op_x.axis = 0
        
        op_y = row.operator(OMONIX_OT_MirrorObjectAxis.bl_idname, text="Y Axis")
        op_y.axis = 1
        
        op_z = row.operator(OMONIX_OT_MirrorObjectAxis.bl_idname, text="Z Axis")
        op_z.axis = 2

    def execute(self, context):
        return {'FINISHED'}

# --- List of Classes for Registration ---
classes_to_register = (
    OMONIX_OT_AddMirrorModifier,
    OMONIX_OT_MirrorObjectAxis,
    OMONIX_OT_MirrorMenu,
)